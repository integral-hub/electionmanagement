<?php

declare(strict_types=1);

namespace App\Actions\Result;

use App\Models\Election;
use Illuminate\Support\Collection;
use Lorisleiva\Actions\Concerns\AsAction;

/**
 * Build the results breakdown (per position, per candidate vote
 * counts + percentages) and turnout timeline for an election,
 * extracted from ResultController.
 */
class GetElectionResultsAction
{
    use AsAction;

    /**
     * @return array{results: Collection, timeline: Collection, totalVotes: int, eligibleVoters: int}
     */
    public function handle(Election $election): array
    {
        $election->load(['positions.candidates.votes', 'setting']);

        $results = $election->positions->map(function ($position) use ($election) {
            $totalVotes = $position->votes()->valid()->where('election_id', $election->id)->count();

            $candidates = $position->candidates->map(function ($candidate) use ($election, $totalVotes) {
                $votes = $candidate->votes()->valid()->where('election_id', $election->id)->count();

                return [
                    'candidate' => $candidate,
                    'votes'     => $votes,
                    'percent'   => $totalVotes > 0 ? round(($votes / $totalVotes) * 100, 1) : 0,
                ];
            })->sortByDesc('votes')->values();

            return [
                'position'    => $position,
                'candidates'  => $candidates,
                'total_votes' => $totalVotes,
            ];
        });

        $eligibleVoters = $election->voters()->wherePivot('status', 'validated')->count();
        $votedCount = $election->votes()->valid()->distinct('voter_id')->count('voter_id');

        return [
            'results'        => $results,
            'timeline'       => $this->buildTimeline($election),
            'totalVotes'     => (int) $results->sum('total_votes'),
            'eligibleVoters' => $eligibleVoters,
            'votedCount'     => $votedCount,
            'turnoutPercent' => $eligibleVoters > 0 ? round(($votedCount / $eligibleVoters) * 100, 1) : 0,
        ];
    }

    /**
     * Cumulative valid votes cast per day, from the first vote (or
     * voting start) through today (or voting end), for the turnout chart.
     */
    private function buildTimeline(Election $election): Collection
    {
        $votesByDay = $election->votes()
            ->valid()
            ->selectRaw('DATE(created_at) as day, COUNT(*) as total')
            ->groupBy('day')
            ->orderBy('day')
            ->pluck('total', 'day');

        if ($votesByDay->isEmpty()) {
            return collect();
        }

        $start = \Carbon\Carbon::parse($votesByDay->keys()->first());
        $end = \Carbon\Carbon::parse($votesByDay->keys()->last())->max(now());

        $running = 0;
        $timeline = collect();

        for ($day = $start->copy(); $day->lte($end); $day->addDay()) {
            $key = $day->toDateString();
            $running += (int) ($votesByDay[$key] ?? 0);

            $timeline->push([
                'date'       => $day->format('M j'),
                'votes'      => (int) ($votesByDay[$key] ?? 0),
                'cumulative' => $running,
            ]);
        }

        return $timeline;
    }
}

