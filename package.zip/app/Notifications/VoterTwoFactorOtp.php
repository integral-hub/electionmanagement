<?php

namespace App\Notifications;

use App\Models\Election;
use App\Models\Voter;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Notifications\Messages\MailMessage;

/**
 * Sent at voter login when voters_require_2fa = true.
 */
class VoterTwoFactorOtp extends Notification
{
    use Queueable;

    public function __construct(
        public readonly Election $election,
        public readonly string   $otp,
    ) {}

    public function via(object $notifiable): array
    {
        return ['mail'];
    }

    public function toMail(Voter $notifiable): MailMessage
    {
        return (new MailMessage)
            ->subject('Your login code — ' . $this->election->name)
            ->greeting('Hello!')
            ->line('Here is your one-time login code for **' . $this->election->name . '**.')
            ->line('It expires in **10 minutes** and can only be used once.')
            ->line('')
            ->line('## ' . $this->otp)
            ->line('')
            ->line('If you did not attempt to log in, please ignore this email.')
            ->salutation('— ' . config('app.name'));
    }
}
