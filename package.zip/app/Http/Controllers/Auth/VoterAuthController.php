<?php

declare(strict_types=1);

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\ForgotPasswordRequest;
use App\Http\Requests\Auth\ResetPasswordRequest;
use App\Http\Requests\Auth\VoterLoginRequest;
use App\Http\Requests\User\UpdatePasswordRequest;
use App\Http\Requests\Voter\CreateRequest;
use App\Models\Election;
use App\Models\Voter;
use App\Services\Interfaces\Auth\VoterAuthInterface;
use App\Services\Interfaces\Auth\PasswordInterface;
use App\Services\Interfaces\Auth\VoterEmailVerificationInterface;
use App\Services\Interfaces\VoterInterface;
use App\Traits\RFValidator;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class VoterAuthController extends Controller
{
    use RFValidator;
    public function __construct(
        private readonly VoterAuthInterface $voterAuth,
        private readonly VoterInterface $voterService,
        private readonly VoterEmailVerificationInterface $verifyEmailService,
        private readonly PasswordInterface $passwordService
    ) {}

    public function notReady(Election $election)
    {
        $can = $election->can_vote;
        
        if ($election->is_portal_ready && $can->allowed) {
            return redirect()->route('voter.login', $election);
        }

        return view('voter.not-ready', compact('election', 'can'));
    }

    //  Show login 

    public function showLogin(Election $election)
    {
        $loginFields = $this->normalizeLoginFields($election, true);
        $election->load('setting');
        return view('voter.login', compact('election', 'loginFields'));
    }

    //  Handle login (step 1)

    public function login(VoterLoginRequest $request, Election $election): RedirectResponse
    {
        /** @var Voter $voter */
        $voter = $request->attributes->get('authorized_voter');

        $result = $this->voterAuth->login($election, $request->validated(), $voter);

        if (! empty($result['requires_2fa'])) {

            session([
                'voter_2fa_id'       => $result['voter_uuid'],
                'voter_2fa_election' => $election->id,
            ]);

            return redirect()->route('voter.2fa', $election);
        }

        return redirect()->route('voter.ballot', $election);
    }

    // link email verification

    public function verifyEmailLink(Election $election, string $token): RedirectResponse
    {
        $result = $this->verifyEmailService->verify(
            $election,
            null,  
            null,  
            $token, 
            false   
        );

        if ($result === true) {
            return redirect()
                ->route('voter.login', $election)
                ->with('success', 'Email verified successfully. You can now log in.');
        }

        return redirect()
            ->route('voter.login', $election)
            ->with('error', 'Invalid or expired verification link.');
    }

    // Email verification OTP (after registration)
    public function showVerifyEmail(Election $election)
    {
        if (! session('voter_verify_id')) {
            return redirect()->route('voter.login', $election);
        }
        return view('voter.verify-email', compact('election'));
    }

    public function verifyEmailOtp(Request $request, Election $election): RedirectResponse
    {
        $voterId = session('voter_verify_id');

        if (! $voterId) {
            return redirect()->route('voter.login', $election);
        }

        $result = $this->verifyEmailService->verify(
            $election,
            $voterId,
            $request->input('otp', ''),
            null,
            false 
        );

        if ($result !== true) {
            return back()->withErrors(['otp' => 'Invalid or expired verification code.']);
        }

        session()->forget('voter_verify_id');

        return redirect()
            ->route('voter.login', $election)
            ->with('success', 'Email verified. You can now log in.');
    }

    // 2FA OTP (during login, step 2)

    public function show2fa(Election $election)
    {
        if (! session('voter_2fa_id')) {
            return redirect()->route('voter.login', $election);
        }
        return view('voter.2fa', compact('election'));
    }

    public function verify2fa(Request $request, Election $election): RedirectResponse
    {
        $voterId = session('voter_2fa_id');

        if (! $voterId) {
            return redirect()->route('voter.login', $election);
        }

        $result = $this->verifyEmailService->verify(
            $election,
            $voterId,
            $request->input('otp', ''),
            null,
            true 
        );

        if (! is_array($result) || ($result['status'] ?? null) !== 'authenticated') {
            return back()->withErrors(['otp' => 'Invalid or expired 2FA code.']);
        }

        // Clean up 2FA session keys (session was already regenerated by the service)
        session()->forget(['voter_2fa_id', 'voter_2fa_election']);

        return redirect()->route('voter.ballot', $election);
    }

    //  Resend OTP 

    public function resendOtp(Request $request, Election $election): RedirectResponse
    {
        $type = $request->query('type', '2fa'); // 'verification' or '2fa'

        $voterUuid = $type === 'verification'
            ? session('voter_verify_id')
            : session('voter_2fa_id');

        if (! $voterUuid) {
            return redirect()->route('voter.login', $election);
        }

        $voter = Voter::query()->where('uuid', $voterUuid)->first();

        if (! $voter) {
            return redirect()->route('voter.login', $election);
        }

        $this->verifyEmailService->send($election, $voter, 'auth');

        return back()->with('success',
            $type === 'verification'
                ? 'A new verification code has been sent to your email.'
                : 'A new login code has been sent to your email.'
        );
    }

    // Registration 

    public function showRegister(Election $election)
    {
        $election->load(['setting', 'registrationField']);

        if (! $election->is_portal_ready) {
            return redirect()
                ->route('voter.login', $election)
                ->with('info', 'Registration is not available for this election.');
        }

        $fields = $election->registrationField?->fields ?? [];
        return view('voter.register', compact('election', 'fields'));
    }

    public function register(CreateRequest $request, Election $election): RedirectResponse
    {
        if (! $election->is_portal_ready) {
            return redirect()
                ->route('voter.login', $election)
                ->with('info', 'Registration is not available for this election.');
        }

        $voter = $this->voterService->create($election, $request->validated());

        $setting          = $election->setting;
        $needsEmailVerify = $setting?->voters_verification_requirement['email'] ?? false;

        if ($needsEmailVerify && $voter->email) {
            session(['voter_verify_id' => $voter->uuid]);

            return redirect()
                ->route('voter.verify-email', $election)
                ->with('info', 'Check your email for a 6-digit verification code.');
        }

        return redirect()
            ->route('voter.login', $election)
            ->with('success', 'Registration successful. You can now log in.');
    }

    public function forgetPassword(string $election)
    {
        return view('voter.forgot-password', compact('election'));
    }

    public function resetPassword(ForgotPasswordRequest $request, Election $election): RedirectResponse
    {
        $this->passwordService->sendResetLink(
            $request->validated(),
            'voters'
        );

        return back()->with('status', 'If that email exists, a reset link has been sent.');
    }

    public function resetView(string $election, string $token, Request $request)
    {
        return view('voter.reset-password', [
            'election' => $election,
            'token' => $token,
            'email' => $request->email,
        ]);
    }

    public function resetStore(Election $election, ResetPasswordRequest $request): RedirectResponse
    {
        $this->passwordService->reset(
            $request->validated(),
            'voters'
        );

        return redirect()->route('voter.login', $election)
            ->with('success', 'Password reset. You can now sign in.');
    }
    public function editPassword(Election $election)
    {
        return view('voter.password', compact('election'));
    }
    public function updatePassword(Election $election, UpdatePasswordRequest $request): RedirectResponse
    {
        $this->passwordService->update(
            voter(),
            $request->validated()
        );

        return redirect()->route('voter.ballot', $election)
            ->with('success', 'Password updated successfully.');
    }

    // Logout

    public function logout(Election $election): RedirectResponse
    {
        $this->voterAuth->logout();

        return redirect()
            ->route('voter.login', $election)
            ->with('success', 'You have been logged out successfully.');
    }
}
