import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';

export default defineConfig({
    plugins: [
        laravel({
            input: [
                'resources/css/app.css',
                'resources/css/admin-layout.css',
                'resources/css/voter-layout.css',
                'resources/css/voter-password.css',
                'resources/css/admin-results.css',
                'resources/css/admin-elections.css',
                'resources/js/app.js',
                'resources/js/admin-layout.js',
                'resources/js/voter-password.js',
            ],
            refresh: true,
        }),
    ]
});
