@extends('layouts.voter')
@section('title','Verify Your Email')

@section('content')
<div class="vcard">
    <div style="text-align:center;margin-bottom:22px;">
        <div style="width:52px;height:52px;background:#f0fdf4;border-radius:14px;display:grid;place-items:center;margin:0 auto 13px;">
            <svg fill="none" stroke="#059669" stroke-width="2" viewBox="0 0 24 24" width="26" height="26">
                <path d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
            </svg>
        </div>
        <h1 style="font-size:21px;font-weight:700;margin-bottom:5px;">Verify Your Email</h1>
        <p style="font-size:13px;color:var(--ink3);">
            We sent a 6-digit code to your email address.<br>
            Enter it below to activate your account.
        </p>
    </div>

    @if(session('success'))
    <div class="valt va-ok">{{ session('success') }}</div>
    @endif
    @if(session('info'))
    <div class="valt va-info">{{ session('info') }}</div>
    @endif
    @if($errors->has('otp'))
    <div class="valt va-err">{{ $errors->first('otp') }}</div>
    @endif

    <style>
.otp-wrap{display:flex;gap:10px;justify-content:center;margin:20px 0}
.otp-wrap input{width:46px;height:56px;text-align:center;font-size:22px;font-weight:700;border:2px solid var(--bdr);border-radius:10px;font-family:inherit;color:var(--ink);background:#fff;outline:none;transition:border .14s;-moz-appearance:textfield}
.otp-wrap input::-webkit-inner-spin-button,.otp-wrap input::-webkit-outer-spin-button{-webkit-appearance:none}
.otp-wrap input:focus{border-color:var(--pr);box-shadow:0 0 0 3px rgba(37,99,235,.12)}
.otp-wrap input.filled{border-color:var(--pr);background:var(--prl)}
</style>

    <form action="{{ route('voter.verify-email.submit', $election) }}" method="POST">
        @csrf
        <input type="hidden" name="otp" id="otpHidden">

        <div class="otp-wrap" aria-label="Enter 6-digit code">
            @for($i = 0; $i < 6; $i++)
            <input type="tel" inputmode="numeric" maxlength="1"
                   class="otp-box" autocomplete="one-time-code"
                   {{ $i === 0 ? 'autofocus' : '' }}>
            @endfor
        </div>

        <button type="submit" class="vbtn vbp">
            Verify Email
            <svg fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24" width="15" height="15">
                <path d="M5 12h14M12 5l7 7-7 7"/>
            </svg>
        </button>
    </form>

    <div style="text-align:center;margin-top:18px;">
        <form action="{{ route('voter.resend-otp', $election) }}?type=verification" method="POST" style="display:inline;">
            @csrf
            <button type="submit" id="resendBtn" disabled style="background:none;border:none;font-family:inherit;font-size:13px;color:var(--pr);cursor:pointer;opacity:.5;">
                Resend code
            </button>
        </form>
        <span id="cdText" style="font-size:12px;color:var(--ink3);margin-left:4px;">Resend in 60s</span>
    </div>

    <div style="text-align:center;margin-top:14px;">
        <a href="{{ route('voter.login', $election) }}" style="font-size:12.5px;color:var(--ink3);">← Back to login</a>
    </div>
</div>

<script>
const boxes = document.querySelectorAll('.otp-box');
const hidden = document.getElementById('otpHidden');

boxes.forEach((box, i) => {
    box.addEventListener('input', e => {
        const val = e.target.value.replace(/\D/g, '').slice(-1);
        box.value = val;
        box.classList.toggle('filled', val !== '');
        syncHidden();
        if (val && i < boxes.length - 1) boxes[i + 1].focus();
    });
    box.addEventListener('keydown', e => {
        if (e.key === 'Backspace' && !box.value && i > 0) {
            boxes[i - 1].value = '';
            boxes[i - 1].classList.remove('filled');
            boxes[i - 1].focus();
            syncHidden();
        }
        if (e.key === 'ArrowLeft' && i > 0) boxes[i - 1].focus();
        if (e.key === 'ArrowRight' && i < boxes.length - 1) boxes[i + 1].focus();
    });
    box.addEventListener('paste', e => {
        e.preventDefault();
        const digits = (e.clipboardData.getData('text') || '').replace(/\D/g, '').slice(0, 6);
        [...digits].forEach((d, j) => {
            if (boxes[j]) { boxes[j].value = d; boxes[j].classList.add('filled'); }
        });
        syncHidden();
        const next = Math.min(digits.length, boxes.length - 1);
        boxes[next].focus();
    });
});

function syncHidden() {
    hidden.value = [...boxes].map(b => b.value).join('');
}

// Countdown for resend cooldown
let cd = 60;
const btn = document.getElementById('resendBtn');
const cdt = document.getElementById('cdText');
if (btn && cdt) {
    const timer = setInterval(() => {
        cd--;
        cdt.textContent = cd > 0 ? `Resend in ${cd}s` : '';
        if (cd <= 0) { btn.disabled = false; btn.style.opacity = '1'; clearInterval(timer); }
    }, 1000);
}
</script>

@endsection
