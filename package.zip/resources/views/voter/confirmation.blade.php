@extends('layouts.voter')
@section('title', 'Vote Confirmed')

@section('content')
<div class="v-card" style="text-align:center;padding:40px 32px;">
    {{-- Animated checkmark --}}
    <div style="width:80px;height:80px;background:#f0fdf4;border-radius:50%;display:grid;place-items:center;margin:0 auto 24px;animation:popIn .4s ease;">
        <svg fill="none" stroke="#059669" stroke-width="2.5" viewBox="0 0 24 24" width="40" height="40">
            <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
    </div>

    <h1 style="font-size:24px;font-weight:700;margin-bottom:8px;">Votes Submitted!</h1>
    <p style="font-size:15px;color:var(--ink-3);margin-bottom:28px;">Your votes for <strong>{{ $election->name }}</strong> have been recorded securely.</p>

    {{-- Vote summary --}}
    @if($castVotes->isNotEmpty())
    <div style="text-align:left;border:1px solid var(--border);border-radius:12px;overflow:hidden;margin-bottom:24px;">
        <div style="padding:12px 16px;background:var(--surface);font-size:12px;font-weight:600;text-transform:uppercase;letter-spacing:.06em;color:var(--ink-3);">Your Choices</div>
        @foreach($castVotes as $vote)
        <div style="padding:14px 16px;display:flex;justify-content:space-between;align-items:center;{{ !$loop->last ? 'border-bottom:1px solid var(--border);' : '' }}">
            <span style="font-size:13px;color:var(--ink-3);">{{ $vote->position->title }}</span>
            <span style="font-size:14px;font-weight:600;">{{ $vote->candidate->name }}</span>
        </div>
        @endforeach
    </div>
    @endif

    <div style="background:var(--primary-light);border-radius:10px;padding:14px 16px;margin-bottom:24px;display:flex;align-items:center;gap:10px;">
        <svg fill="none" stroke="var(--primary)" stroke-width="2" viewBox="0 0 24 24" width="18" height="18" style="flex-shrink:0;">
            <path d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/>
        </svg>
        <span style="font-size:13px;color:#1d4ed8;">Your vote is anonymous and securely stored. No one can see who you voted for.</span>
    </div>

    <form action="{{ route('voter.logout', $election) }}" method="POST">
        @csrf
        <button type="submit" class="v-btn v-btn-secondary" style="margin-bottom:10px;">Sign Out</button>
    </form>
    <p style="font-size:12px;color:var(--ink-3);margin-top:8px;">
        Results will be available once voting closes.
    </p>
</div>

<style>
@keyframes popIn {
    from { transform: scale(0.5); opacity: 0; }
    to   { transform: scale(1);   opacity: 1; }
}
</style>
@endsection
