@extends('layouts.voter')
@section('title', 'Voter Login')

@section('content')
<div class="v-card">
    <div style="text-align:center;margin-bottom:28px;">
        <div style="width:56px;height:56px;background:var(--primary-light);border-radius:16px;display:grid;place-items:center;margin:0 auto 16px;">
            <svg fill="none" stroke="var(--primary)" stroke-width="2" viewBox="0 0 24 24" width="28" height="28">
                <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/>
                <circle cx="12" cy="7" r="4"/>
            </svg>
        </div>

        <h1 style="font-size:22px;font-weight:700;margin-bottom:6px;">Voter Login</h1>
        <p style="font-size:14px;color:var(--ink-3);">
            Enter your credentials to access the ballot.
        </p>
    </div>

    @if($errors->any())
        <div class="v-alert v-alert-error">
            {{ $errors->first() }}
        </div>
    @endif

    <form action="{{ route('voter.login.submit', $election) }}" method="POST">
        @csrf

        @foreach($loginFields as $field)

            @switch($field['key'])

                @case('email')
                    <div class="v-form-group">
                        <label class="v-label" for="email">
                            {{ $field['label'] }}
                            <span style="color:#dc2626;">*</span>
                        </label>

                        <input
                            type="email"
                            id="email"
                            name="email"
                            class="v-input"
                            placeholder="you@example.com"
                            value="{{ old('email') }}"
                            autocomplete="email"
                            required>
                    </div>
                    @break

                @case('phone')
                    <div class="v-form-group">
                        <label class="v-label" for="phone">
                            {{ $field['label'] }}
                            <span style="color:#dc2626;">*</span>
                        </label>

                        <input
                            type="tel"
                            id="phone"
                            name="phone"
                            class="v-input"
                            placeholder="+234 7xxxxxxxxx"
                            value="{{ old('phone') }}"
                            required>
                    </div>
                    @break

                @case('password')
                    <div class="v-form-group">
                        <label class="v-label" for="password">
                            {{ $field['label'] }}
                            <span style="color:#dc2626;">*</span>
                        </label>

                        <div style="position:relative;">
                            <input
                                type="password"
                                id="password"
                                name="password"
                                class="v-input"
                                placeholder="Password"
                                autocomplete="current-password"
                                style="padding-right:44px;"
                                required>

                            <button
                                type="button"
                                onclick="togglePwd(this)"
                                style="position:absolute;right:12px;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;color:var(--ink-3);">
                                👁
                            </button>
                        </div>
                                <!-- FORGOT PASSWORD -->
                        <div style="text-align:right;margin-top:6px;">
                            <a href="{{ route('voter.password.request', $election) }}"
                            style="font-size:12px;color:var(--primary);text-decoration:none;">
                                Forgot password?
                            </a>
                        </div>
                    </div>
                    @break

                @default
                    <div class="v-form-group">
                        <label class="v-label" for="{{ $field['key'] }}">
                            {{ $field['label'] }}
                            <span style="color:#dc2626;">*</span>
                        </label>

                        <input
                            type="text"
                            id="{{ $field['key'] }}"
                            name="{{ $field['key'] }}"
                            class="v-input"
                            value="{{ old($field['key']) }}"
                            placeholder="Enter your {{ strtolower($field['label']) }}"
                            required>
                    </div>

            @endswitch

        @endforeach

        <button type="submit" class="v-btn v-btn-primary" style="margin-top:8px;">
            Access Ballot
            <svg fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24" width="16" height="16">
                <path d="M5 12h14M12 5l7 7-7 7"/>
            </svg>
        </button>
    </form>

    @if($election->is_registration_open)
        <div class="v-divider">or</div>

        <a href="{{ route('voter.register', $election) }}" class="v-btn v-btn-secondary">
            Register as a Voter
        </a>
    @endif
</div>

<div style="text-align:center;margin-top:20px;font-size:12px;color:var(--ink-3);">
    Your vote is private and secure. &nbsp;·&nbsp; Powered by {{ config('app.name') }}
</div>

<script>
function togglePwd(btn) {
    const input = btn.previousElementSibling;
    input.type = input.type === 'password' ? 'text' : 'password';
}
</script>
@endsection