@extends('layouts.admin')
@section('page-title', 'Results — ' . $election->name)

@push('styles')
    @vite('resources/css/admin-results.css')
@endpush

@section('topbar-actions')
    <a href="{{ route('admin.elections.show', $election) }}" class="btn btn-secondary btn-sm">← Election</a>
@endsection

@section('content')

@php
    $electionStatus = $election->status;

    $electionStatusColor = match($electionStatus) {
        'completed' => '#16a34a',
        'cancelled'    => '#dc2626',
        'running'   => '#f59e0b',
        'scheduled'   => '#4f46e5',
        'paused'   => '#9ca3af',
        default     => '#4f46e5',
    };
@endphp

{{-- ELECTION STATUS HEADER --}}
<div class="card results-header">
    <div>
        <div class="card-title">{{ $election->name }}</div>
        <div class="results-header-sub">Election results overview</div>
    </div>

    <span class="status-pill" style="color: {{ $electionStatusColor }};">
        {{ $electionStatus }}
    </span>
</div>

{{-- TURNOUT SUMMARY --}}
<div class="card turnout-grid">
    <div class="turnout-donut-wrap">
        <div class="turnout-donut" style="--pct: {{ $turnoutPercent }}">
            <div class="turnout-donut-inner">
                <div class="turnout-donut-value">{{ $turnoutPercent }}%</div>
                <div class="turnout-donut-label">Turnout</div>
            </div>
        </div>
    </div>

    <div class="turnout-stats">
        <div>
            <div class="turnout-stat-label">Eligible Voters</div>
            <div class="turnout-stat-value">{{ number_format($eligibleVoters) }}</div>
        </div>
        <div>
            <div class="turnout-stat-label">Voters Who Voted</div>
            <div class="turnout-stat-value">{{ number_format($votedCount) }}</div>
        </div>
        <div>
            <div class="turnout-stat-label">Total Ballots Cast</div>
            <div class="turnout-stat-value">{{ number_format($totalVotes) }}</div>
        </div>
    </div>
</div>

{{-- VOTING TIMELINE --}}
@if($timeline->isNotEmpty())
    @php
        $maxCumulative = max(1, $timeline->max('cumulative'));
        $width = 700;
        $height = 160;
        $count = $timeline->count();
        $stepX = $count > 1 ? $width / ($count - 1) : 0;

        $points = $timeline->values()->map(function ($point, $i) use ($stepX, $height, $maxCumulative) {
            $x = round($i * $stepX, 1);
            $y = round($height - (($point['cumulative'] / $maxCumulative) * ($height - 10)) - 5, 1);
            return ['x' => $x, 'y' => $y, 'date' => $point['date'], 'cumulative' => $point['cumulative'], 'votes' => $point['votes']];
        });

        $linePath = $points->map(fn ($p) => "{$p['x']},{$p['y']}")->implode(' ');
        $areaPath = "0,{$height} " . $linePath . " {$width},{$height}";
    @endphp

    <div class="card">
        <div class="card-header">
            <div>
                <div class="card-title">Voting Timeline</div>
                <div class="results-header-sub">Cumulative ballots cast over time</div>
            </div>
        </div>

        <div class="timeline-chart-wrap">
            <svg class="timeline-svg" viewBox="0 0 {{ $width }} {{ $height }}" preserveAspectRatio="none">
                <line class="timeline-axis" x1="0" y1="{{ $height - 1 }}" x2="{{ $width }}" y2="{{ $height - 1 }}" />
                <polygon class="timeline-area" points="{{ $areaPath }}" />
                <polyline class="timeline-line" points="{{ $linePath }}" />
                @foreach($points as $p)
                    <circle class="timeline-point" cx="{{ $p['x'] }}" cy="{{ $p['y'] }}" r="3">
                        <title>{{ $p['date'] }}: {{ number_format($p['cumulative']) }} total ({{ number_format($p['votes']) }} that day)</title>
                    </circle>
                @endforeach
            </svg>
            <div class="timeline-labels">
                <span>{{ $points->first()['date'] }}</span>
                @if($points->count() > 1)
                    <span>{{ $points->last()['date'] }}</span>
                @endif
            </div>
        </div>
    </div>
@endif

{{-- POSITION RESULTS --}}
@if($results->isEmpty())
    <div class="card">
        <div class="empty-state results-empty">
            <svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
                <polyline points="22,12 18,12 15,21 9,3 6,12 2,12"/>
            </svg>
            <div class="empty-title">No results yet</div>
            <p>Results will appear once voting begins.</p>
        </div>
    </div>
@else
    @foreach($results as $result)
    <div class="card result-card">
        <div class="card-header">
            <div>
                <div class="card-title">{{ $result['position']->title }}</div>
                <div class="result-card-sub">{{ number_format($result['total_votes']) }} votes cast</div>
            </div>
            <span class="result-candidate-count">{{ count($result['candidates']) }} candidates</span>
        </div>

        <div class="candidate-list">
            @foreach($result['candidates'] as $i => $item)
                @php
                    $candidate = $item['candidate'];
                    $votes = $item['votes'];
                    $pct = $item['percent'];

                    $candidateStatus = $candidate->status;

                    $candidateStatusColor = match($candidateStatus) {
                        'active'    => '#16a34a',
                        'withdrawn'  => '#6b7280',
                        default     => '#6b7280',
                    };
                @endphp

                <div class="candidate-row">
                    <div class="candidate-rank {{ $i === 0 && $votes > 0 ? 'is-leading' : '' }}">{{ $i + 1 }}</div>

                    <div class="candidate-photo">
                        @if(data_get($candidate, 'photo.url'))
                            <img src="{{ data_get($candidate, 'photo.url') }}" alt="{{ $candidate->name }}">
                        @endif
                    </div>

                    <div class="candidate-details">
                        <div class="candidate-details-top">
                            <span class="candidate-name">{{ $candidate->name }}</span>
                            <span class="candidate-tally">
                                {{ $pct }}%
                                <span class="candidate-tally-count">({{ number_format($votes) }})</span>
                            </span>
                        </div>

                        <div class="candidate-bar-track">
                            <div class="candidate-bar-fill" style="width: {{ $pct }}%;"></div>
                        </div>

                        <div class="candidate-status-wrap">
                            <span class="candidate-status" style="color: {{ $candidateStatusColor }};">
                                {{ $candidateStatus }}
                            </span>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
    @endforeach
@endif

@endsection
