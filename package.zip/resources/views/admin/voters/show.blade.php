@extends('layouts.admin')
@section('page-title', 'Voter Status')

@section('page-subtitle')
    @php
        $pivotStatus = $pivot?->status ?? 'pending';

        $statusMap = [
            'validated' => ['b-running', 'Validated'],
            'banned'    => ['b-rejected', 'Banned'],
            'pending'   => ['b-scheduled', 'Pending'],
        ];

        [$badgeClass, $statusLabel] = $statusMap[$pivotStatus] ?? ['b-draft', ucfirst($pivotStatus)];
    @endphp

    <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
        <span class="badge {{ $badgeClass }}">
            <span class="bd"></span>{{ $statusLabel }}
        </span>
    </div>
@endsection

@section('topbar-actions')
    <a href="{{ route('admin.elections.voters.index', $election) }}" class="btn btn-s btn-sm">← Voters</a>

    @can('update', $voter)
    <a href="{{ route('admin.elections.voters.edit', [$election, $voter]) }}" class="btn btn-p btn-sm">
        <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="13" height="13"><path d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
        Edit
    </a>
    @endcan

@endsection

@section('content')

{{-- Status bar --}}
<div style="display:flex;align-items:center;gap:12px;margin-bottom:20px;flex-wrap:wrap;">

    @if($pivot?->validated_at)
        <span style="font-size:12px;color:var(--ink3);">
            {{ ucfirst($pivot?->status) }} by
            <strong>
                @if($pivot->validated_by === auth()->id())
                    You
                @else
                    {{ $pivot->validator?->name ?? 'Unknown User' }}
                    @if($pivot->validator?->getRoleNames()->isNotEmpty())
                        ({{ ucfirst($pivot->validator->getRoleNames()->first()) }})
                    @endif
                @endif
            </strong>
            on {{ \Carbon\Carbon::parse($pivot->validated_at)->format('M j, Y \a\t H:i') }}
        </span>
    @endif

    @if($pivotStatus !== 'validated')
    @can('approve', $voter)
    <form action="{{ route('admin.elections.voters.approve', [$election, $voter]) }}" method="POST" style="display:inline;">
        @csrf @method('PATCH')
        <button type="submit" class="btn btn-sg btn-sm">
            <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="13" height="13"><path d="M5 13l4 4L19 7"/></svg>
            Approve
        </button>
    </form>
    @endcan
    @endif

    @if($pivotStatus !== 'banned')
    @can('reject', $voter)
    <form action="{{ route('admin.elections.voters.reject', [$election, $voter]) }}" method="POST" style="display:inline;">
        @csrf @method('PATCH')
        <button type="submit" class="btn btn-d btn-sm"
                onclick="return confirm('Ban this voter from the election?')">
            <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="13" height="13"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            Ban
        </button>
    </form>
    @endcan
    @endif

    @can('delete', $voter)
    <form action="{{ route('admin.elections.voters.destroy', [$election, $voter]) }}" method="POST" style="display:inline;">
        @csrf @method('DELETE')
        <button type="submit" class="btn btn-d btn-sm"
                onclick="return confirm('Remove this voter from the election?')">
            Remove
        </button>
    </form>
    @endcan
</div>

<div style="display:grid;grid-template-columns:320px 1fr;gap:18px;align-items:start;">

    {{-- ── Left column: core identity ──────────────────────────────────────── --}}
    <div style="display:flex;flex-direction:column;gap:16px;">

        {{-- Identity card --}}
        <div class="card">
            <div class="ch" style="margin-bottom:14px;"><div class="ct">Identity</div></div>

            <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;">
                <div style="width:50px;height:50px;border-radius:50%;background:var(--acl);display:grid;place-items:center;flex-shrink:0;font-size:19px;font-weight:700;color:var(--ac);">
                    {{ strtoupper(substr($voter->email ?? $voter->phone ?? 'V', 0, 1)) }}
                </div>
                <div>
                    <div style="font-size:13.5px;font-weight:600;">{{ $voter->email ?? $voter->phone ?? 'Unknown' }}</div>
                </div>
            </div>

            {{-- Email --}}
            <div style="padding:9px 0;border-bottom:1px solid var(--bdr);">
                <div style="font-size:10.5px;font-weight:600;text-transform:uppercase;letter-spacing:.05em;color:var(--ink3);margin-bottom:3px;">Email</div>
                @if($voter->email)
                <div style="display:flex;align-items:center;gap:7px;">
                    <span style="font-size:13px;">{{ $voter->email }}</span>
                    @if($voter->is_verified_email)
                        <span style="font-size:10.5px;color:var(--ok);background:#f0fdf4;padding:2px 7px;border-radius:20px;">✓ Verified</span>
                    @else
                        <span style="font-size:10.5px;color:var(--warn);background:#fffbeb;padding:2px 7px;border-radius:20px;">Unverified</span>
                    @endif
                </div>
                @else
                <span style="font-size:13px;color:var(--ink3);">—</span>
                @endif
            </div>

            {{-- Phone --}}
            <div style="padding:9px 0;border-bottom:1px solid var(--bdr);">
                <div style="font-size:10.5px;font-weight:600;text-transform:uppercase;letter-spacing:.05em;color:var(--ink3);margin-bottom:3px;">Phone</div>
                <div style="font-size:13px;">{{ $voter->phone ?? '—' }}</div>
            </div>

            {{-- Batch code — from voters table --}}
            <div style="padding:9px 0;border-bottom:1px solid var(--bdr);">
                <div style="font-size:10.5px;font-weight:600;text-transform:uppercase;letter-spacing:.05em;color:var(--ink3);margin-bottom:3px;">Batch Code</div>
                @if($voter->batch_code)
                <code style="font-size:12px;background:var(--sur);padding:2px 7px;border-radius:4px;">{{ $voter->batch_code }}</code>
                @else
                <span style="font-size:13px;color:var(--ink3);">—</span>
                @endif
            </div>

            {{-- Last login --}}
            <div style="padding:9px 0;border-bottom:1px solid var(--bdr);">
                <div style="font-size:10.5px;font-weight:600;text-transform:uppercase;letter-spacing:.05em;color:var(--ink3);margin-bottom:3px;">Last Login</div>
                <div style="font-size:13px;">{{ $voter->last_login_at?->format('M j, Y H:i') ?? '—' }}</div>
            </div>

            {{-- Registered --}}
            <div style="padding:9px 0;">
                <div style="font-size:10.5px;font-weight:600;text-transform:uppercase;letter-spacing:.05em;color:var(--ink3);margin-bottom:3px;">Registered</div>
                <div style="font-size:13px;color:var(--ink2);">{{ $voter->created_at->format('M j, Y \a\t H:i') }}</div>
            </div>
        </div>

        {{-- Election status card --}}
        <div class="card">
            <div class="ch" style="margin-bottom:14px;"><div class="ct">Election Details</div></div>
            <div style="display:flex;flex-direction:column;gap:10px;">
                <div>
                    <div style="font-size:10.5px;font-weight:600;text-transform:uppercase;letter-spacing:.05em;color:var(--ink3);margin-bottom:3px;">Election</div>
                    <div style="font-size:13.5px;font-weight:500;">{{ $election->name }}</div>
                </div>
                <div>
                    <div style="font-size:10.5px;font-weight:600;text-transform:uppercase;letter-spacing:.05em;color:var(--ink3);margin-bottom:3px;">Status</div>
                    <span class="badge {{ $badgeClass }}" style="font-size:11.5px;"><span class="bd"></span>{{ $statusLabel }}</span>
                </div>
                @if($voter->hasVote($election))
                <div>
                    <div style="font-size:10.5px;font-weight:600;text-transform:uppercase;letter-spacing:.05em;color:var(--ink3);margin-bottom:6px;">Voting Status</div>
                        <span class="badge b-completed" style="font-size:12px;padding:3px 10px;">
                            <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="11" height="11" style="margin-right:3px;"><polyline points="9,11 12,14 22,4"/></svg>
                            Voted
                        </span>
                </div>
                @endif
            </div>
        </div>
    </div>

    {{-- ── Right column: registration data  --}}
    <div style="display:flex;flex-direction:column;gap:16px;">

        {{-- voter_data fields --}}
        @if(!empty($voter->voter_data))
        <div class="card">
            <div class="ch" style="margin-bottom:14px;">
                <div class="ct">Bio Data</div>
            </div>
            <div>
                @foreach($voter->voter_data as $fieldName => $value)
                @php
                    $def   = $fieldDefs->get($fieldName);
                    $label = $def['label'] ?? ucwords(str_replace('_', ' ', $fieldName));
                    $type  = $def['field_type'] ?? 'text';
                    $isFile = $type === 'file';
                @endphp
                <div style="display:grid;grid-template-columns:150px 1fr;gap:10px;padding:10px 0;{{ !$loop->last ? 'border-bottom:1px solid var(--bdr);' : '' }}align-items:start;">
                    <div style="font-size:11.5px;font-weight:600;color:var(--ink3);padding-top:2px;">{{ $label }}</div>
                    <div>
                        @if($isFile && $value)
                            @php
                                $ext = strtolower($value['format']);
                                $isImage = in_array($ext, ['jpg', 'jpeg', 'png']);
                                $isPdf = $ext === 'pdf';
                                $previewUrl = route('admin.elections.voters.file-preview', [$election, $voter, $fieldName]);
                            @endphp
                            <div style="display:flex;flex-direction:column;gap:8px;">
                                @if($isImage)
                                <a href="{{ $previewUrl }}" target="_blank" rel="noopener"
                                   style="display:inline-block;border-radius:8px;overflow:hidden;border:1px solid var(--bdr);max-width:200px;">
                                    <img src="{{ $previewUrl }}" alt="{{ $label }}"
                                         style="width:100%;max-height:140px;object-fit:cover;display:block;">
                                </a>
                                @elseif($isPdf)
                                <div style="border:1px solid var(--bdr);border-radius:8px;overflow:hidden;">
                                    <iframe src="{{ $previewUrl }}" style="width:100%;height:200px;border:none;display:block;" title="{{ $label }}"></iframe>
                                </div>
                                @else
                                <div style="display:flex;align-items:center;gap:8px;padding:9px 12px;border:1px solid var(--bdr);border-radius:8px;background:var(--sur);">
                                    <svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24" width="26" height="26" style="color:var(--ac);flex-shrink:0;"><path d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                                    <div>
                                        <div style="font-size:13px;font-weight:500;">{{ $filename }}</div>
                                        <div style="font-size:11px;color:var(--ink3);">{{ strtoupper($ext) }}</div>
                                    </div>
                                </div>
                                @endif
                                <div style="display:flex;gap:7px;">
                                    <a href="{{ $previewUrl }}" target="_blank" rel="noopener" class="btn btn-s btn-sm" style="font-size:11.5px;">
                                        <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="12" height="12"><path d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
                                        Open
                                    </a>
                                </div>
                            </div>

                        @elseif(is_array($value))
                            <div style="font-size:13px;">{{ implode(', ', $value) }}</div>

                        @elseif(in_array($value, [true, false, '1', '0', 1, 0], true))
                            <span class="badge {{ $value ? 'b-running' : 'b-draft' }}" style="font-size:11px;">
                                {{ $value ? 'Yes' : 'No' }}
                            </span>

                        @else
                            <div style="font-size:13.5px;word-break:break-word;">{{ $value ?: '—' }}</div>
                        @endif
                    </div>
                </div>
                @endforeach
            </div>
        </div>
        @endif

        {{-- voter_unique_data fields --}}
        @if($voter->uniqueData->isNotEmpty())
        <div class="card">
            <div class="ch" style="margin-bottom:14px;">
                <div class="ct">Additional Information</div>
            </div>
            <div>
                @foreach($voter->uniqueData as $ud)
                @php
                    $def   = $fieldDefs->get($ud->field_name);
                    $label = $def['label'] ?? ucwords(str_replace('_', ' ', $ud->field_name));
                @endphp
                <div style="display:grid;grid-template-columns:150px 1fr;gap:10px;padding:9px 0;{{ !$loop->last ? 'border-bottom:1px solid var(--bdr);' : '' }}align-items:center;">
                    <div>
                        <div style="font-size:11.5px;font-weight:600;color:var(--ink3);">{{ $label }} :</div>
                    </div>
                    <div style="display:flex;align-items:center;gap:8px;">
                        <span style="font-size:13.5px;font-weight:500;word-break:break-all;">{{ $ud->value }}</span>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
        @endif

        {{-- Empty state --}}
        @if(empty($voter->voter_data) && $voter->uniqueData->isEmpty())
        <div class="card">
            <div class="es" style="padding:28px;">
                <svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                <div class="et">Bio data not supplied or required</div>
            </div>
        </div>
        @endif
    </div>
</div>

<style>
@media (max-width:768px) {
    [style*="grid-template-columns:320px"] { grid-template-columns:1fr !important; }
}
</style>
@endsection
