<?php $__env->startSection('page-title', 'Staff / Users'); ?>

<?php $__env->startSection('topbar-actions'); ?>
    <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-primary btn-sm">
        <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="16" height="16"><path d="M12 5v14M5 12h14"/></svg>
        Invite Staff
    </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <div class="card-title">Team Members</div>
        <span style="font-size:13px;color:var(--ink-3);"><?php echo e($users->total()); ?> members</span>
    </div>

    <?php if($users->isEmpty()): ?>
        <div class="empty-state">
            <svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/></svg>
            <div class="empty-title">No staff yet</div>
            <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-primary btn-sm" style="margin-top:12px;">Invite Someone</a>
        </div>
    <?php else: ?>
    <div class="table-wrap">
        <table>
            <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Joined</th><th>Actions</th></tr></thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <div style="display:flex;align-items:center;gap:10px;">
                            <div class="user-avatar" style="width:32px;height:32px;font-size:12px;">
                                <?php if($url = data_get($user, 'profile_photo_path.url')): ?>
                                <img src="<?php echo e($url); ?>" alt="<?php echo e($user->name); ?>">
                                <?php endif; ?>
                            </div>
                            <span style="font-weight:500;"><?php echo e($user->name); ?></span>
                        </div>
                    </td>
                    <td style="color:var(--ink-3);"><?php echo e($user->email); ?></td>
                    <td>
                        <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="badge badge-scheduled"><?php echo e($role->name); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td style="color:var(--ink-3);font-size:13px;"><?php echo e($user->created_at->format('M j, Y')); ?></td>
                    <td>
                        <div style="display:flex;gap:6px;">
                            <a href="<?php echo e(route('admin.users.edit', $user)); ?>" class="btn btn-secondary btn-sm">Edit</a>
                            <form action="<?php echo e(route('admin.users.destroy', $user)); ?>" method="POST">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger btn-sm" onclick="return confirm('Remove user?')">Remove</button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div style="padding-top:16px;"><?php echo e($users->links()); ?></div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\electionmanagement\resources\views/admin/users/index.blade.php ENDPATH**/ ?>