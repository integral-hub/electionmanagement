<?php echo e($slot); ?>

<?php /**PATH C:\laragon\www\electionmanagement\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>