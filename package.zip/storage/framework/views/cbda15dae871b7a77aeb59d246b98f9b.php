<?php $__env->startSection('page-title', $election->name); ?>

<?php $__env->startSection('topbar-actions'); ?>
    <a href="<?php echo e(route('admin.elections.index')); ?>" class="btn btn-secondary btn-sm">← Elections</a>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $election)): ?><a href="<?php echo e(route('admin.elections.edit', $election)); ?>" class="btn btn-secondary btn-sm">Edit</a><?php endif; ?>
   <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $election->setting)): ?> <a href="<?php echo e(route('admin.elections.settings', $election)); ?>" class="btn btn-secondary btn-sm">Settings</a> <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div style="display:flex;align-items:center;gap:16px;margin-bottom:24px;flex-wrap:wrap;">
    <span class="badge badge-<?php echo e($election->status); ?>" style="font-size:13px;padding:5px 14px;">
        <span class="badge-dot"></span><?php echo e(ucfirst($election->status)); ?>

    </span>
    <?php if($election->setting?->voting_start): ?>
    <span style="font-size:13px;color:var(--ink-3);">
        <strong>Start:</strong> <?php echo e($election->setting->voting_start->format('d M Y, H:i')); ?>

    </span>
    <?php endif; ?>
    <?php if($election->setting?->voting_end): ?>
    <span style="font-size:13px;color:var(--ink-3);">
        <strong>End:</strong> <?php echo e($election->setting->voting_end->format('d M Y, H:i')); ?>

    </span>
    <?php endif; ?>
    <span style="margin-left:auto;">
        <a href="<?php echo e(route('voter.login', $election)); ?>" target="_blank" class="btn btn-secondary btn-sm">
            <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="14" height="14"><path d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
            Voter Portal
        </a>
    </span>
</div>

<div class="card" style="margin-bottom:24px;">
    <div class="card-header">
        <div>
            <div class="card-title">Portal Setup Progress</div>
            <div style="font-size:13px;color:var(--ink-3);margin-top:4px;">
                Track election readiness before opening the voter portal.
            </div>
        </div>

        <div style="text-align:right;">
            <div style="
                font-size:28px;
                font-weight:700;
                color:<?php echo e($progress === 100 ? '#16a34a' : 'var(--accent)'); ?>;
            ">
                <?php echo e($progress); ?>%
            </div>
            <div style="font-size:12px;color:var(--ink-3);">
                Complete
            </div>
        </div>
    </div>

 
<div style="
    height:10px;
    background:#e5e7eb;
    border-radius:999px;
    overflow:hidden;
    margin-bottom:18px;
">
    <div style="
        height:100%;
        width:<?php echo e($progress); ?>%;
        background:<?php echo e($progress === 100 ? '#16a34a' : 'var(--accent)'); ?>;
        transition:width .3s ease;
    "></div>
</div>


<div style="display:grid;gap:10px;">

    <?php $__currentLoopData = $checklist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php
            // Hide voting_dates until core setup is done
            if (isset($item['visible']) && $item['visible'] === false) {
                continue;
            }

            // Hide completed items except voting_dates
            if ($item['done'] && $key !== 'voting_dates') {
                continue;
            }
        ?>

        <div style="
            display:flex;
            justify-content:space-between;
            align-items:center;
            gap:12px;
            padding:14px;
            border:1px solid var(--border);
            border-radius:10px;
            background:<?php echo e($item['done'] ? '#f0fdf4' : '#fff'); ?>;
        ">

            
            <div style="display:flex;align-items:flex-start;gap:12px;">

                
                <?php if($item['done']): ?>
                    <div style="
                        width:24px;
                        height:24px;
                        border-radius:50%;
                        background:#dcfce7;
                        color:#16a34a;
                        display:flex;
                        align-items:center;
                        justify-content:center;
                        font-size:13px;
                        font-weight:700;
                        flex-shrink:0;
                    ">
                        ✓
                    </div>
                <?php else: ?>
                    <div style="
                        width:24px;
                        height:24px;
                        border-radius:50%;
                        background:#fee2e2;
                        color:#dc2626;
                        display:flex;
                        align-items:center;
                        justify-content:center;
                        font-size:13px;
                        font-weight:700;
                        flex-shrink:0;
                    ">
                        !
                    </div>
                <?php endif; ?>

                
                <div>
                    <div style="font-weight:600;font-size:14px;">
                        <?php echo e($item['label']); ?>

                    </div>

                    <?php if(! $item['done'] && ! empty($item['hint'])): ?>
                        <div style="
                            font-size:12px;
                            color:#dc2626;
                            margin-top:3px;
                        ">
                            <?php echo e($item['hint']); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>

            
            <div style="display:flex;align-items:center;gap:10px;">

                <?php if($item['done'] && $key !== 'voting_dates'): ?>
                    <span style="
                        color:#16a34a;
                        font-size:12px;
                        font-weight:600;
                    ">
                        Completed
                    </span>

                <?php elseif(! empty($item['route'])): ?>
                  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update.election_settings')): ?> <a href="<?php echo e($item['route']); ?>" class="btn btn-primary btn-sm">
                        <?php echo e($item['action']); ?>

                    </a>
                  <?php endif; ?>

                <?php else: ?>
                    <button type="button" class="btn btn-secondary btn-sm" disabled>
                        <?php echo e($item['action']); ?>

                    </button>
                <?php endif; ?>

            </div>
        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php
    $pendingItems = collect($checklist)->filter(function ($item, $key) {
        if (isset($item['visible']) && $item['visible'] === false) return false;
        if ($item['done'] && $key !== 'voting_dates') return false;
        return !$item['done'];
    })->count();
?>


<?php if($progress === 100): ?>
    <div class="alert alert-success" style="margin-top:16px;">
        <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
        </svg>
        Election portal is fully configured and ready.
    </div>
<?php else: ?>
    <div class="alert alert-info" style="margin-top:16px;">
        <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <circle cx="12" cy="12" r="10"/>
            <path d="M12 8v4m0 4h.01"/>
        </svg>
        <?php echo e($pendingItems); ?> setup item<?php echo e($pendingItems > 1 ? 's' : ''); ?> still require attention.
    </div>
<?php endif; ?>

<div class="stats-grid" style="margin-bottom:24px;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));">
    <?php $__currentLoopData = [['Positions',$election->positions->count(),'#eef2ff','#4f46e5'],['Candidates',$election->candidates->count(),'#fef9c3','#d97706'],['Voters',$election->voters_count,'#dcfce7','#059669'],['Votes Cast',$election->votes_count,'#ede9fe','#7c3aed']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$lbl,$val,$bg,$clr]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="stat-card" style="padding:16px;">
        <div style="font-size:24px;font-weight:700;color:<?php echo e($clr); ?>;"><?php echo e($val ?? 0); ?></div>
        <div class="stat-label"><?php echo e($lbl); ?></div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<div style="border-bottom:1px solid var(--border);margin-bottom:24px;display:flex;gap:0;overflow-x:auto;" id="electionTabs">
    <?php $__currentLoopData = ['positions'=>'Positions','candidates'=>'Candidates','voters'=>'Voters','registration'=>'Reg. Form','results'=>'Results']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tab => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <button onclick="showTab('<?php echo e($tab); ?>')" id="tab-<?php echo e($tab); ?>" class="tab-btn" style="padding:10px 18px;font-size:14px;font-weight:500;border:none;background:none;cursor:pointer;border-bottom:2px solid transparent;color:var(--ink-3);white-space:nowrap;transition:all .15s;font-family:inherit;"><?php echo e($label); ?></button>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<div id="pane-positions" class="tab-pane">
    <div class="card">
        <div class="card-header">
            <div class="card-title">Positions</div>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create.positions')): ?>  <a href="<?php echo e(route('admin.elections.positions.create', $election)); ?>" class="btn btn-primary btn-sm">+ Add Position</a> <?php endif; ?>
        </div>
        <?php if($election->positions->isEmpty()): ?>
            <div class="empty-state">
                <svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v2"/></svg>
                <div class="empty-title">No positions yet</div>
                <p style="font-size:13px;">Add a position like "President" or "Secretary".</p>
            </div>
        <?php else: ?>
        <div class="table-wrap">
            <table>
                <thead><tr><th>Title</th><th>Description</th><th>Candidates</th><th>Actions</th></tr></thead>
                <tbody>
                <?php $__currentLoopData = $election->positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td style="font-weight:500;"><?php echo e($position->title); ?></td>
                    <td style="color:var(--ink-3);font-size:13px;"><?php echo e($position->description ?: '—'); ?></td>
                    <td><?php echo e($position->candidates->count()); ?></td>
                    <td>
                        <div style="display:flex;gap:6px;">
                          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $position)): ?>  <a href="<?php echo e(route('admin.elections.positions.edit', [$election, $position])); ?>" class="btn btn-secondary btn-sm">Edit</a> <?php endif; ?>
                          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $position)): ?>
                            <form action="<?php echo e(route('admin.elections.positions.destroy', [$election, $position])); ?>" method="POST">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Delete position?')">Remove</button>
                            </form>
                          <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>


<div id="pane-candidates" class="tab-pane" style="display:none;">
    <div class="card">
        <div class="card-header">
            <div class="card-title">Candidates</div>
            <?php if($election->positions->isNotEmpty()): ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create.candidates')): ?>
            <a href="<?php echo e(route('admin.elections.candidates.create', $election)); ?>" class="btn btn-primary btn-sm">+ Add Candidate</a>
            <?php endif; ?>
            <?php endif; ?>
        </div>
        <?php $allCandidates = $election->positions->flatMap(fn($p) => $p->candidates->map(fn($c) => ['candidate'=>$c,'position'=>$p])); ?>
        <?php if($allCandidates->isEmpty()): ?>
            <div class="empty-state">
                <svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                <div class="empty-title">No candidates yet</div>
            </div>
        <?php else: ?>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:14px;">
            <?php $__currentLoopData = $allCandidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as ['candidate' => $c, 'position' => $p]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div style="border:1px solid var(--border);border-radius:10px;padding:16px;display:flex;gap:12px;">
                <div style="width:44px;height:44px;border-radius:50%;overflow:hidden;flex-shrink:0;background:var(--surface);">
                <?php if(data_get($c, 'photo.url')): ?>
                    <img src="<?php echo e(data_get($c, 'photo.url')); ?>"
                    alt="<?php echo e($c->name); ?>">
                <?php endif; ?>
                </div>
                <div style="flex:1;min-width:0;">
                    <div style="font-weight:600;font-size:14px;"><?php echo e($c->name); ?></div>
                    <div style="font-size:12px;color:var(--accent);margin-bottom:4px;"><?php echo e($p->title); ?></div>
                    <span class="badge badge-<?php echo e($c->status); ?>" style="font-size:11px;"><?php echo e(ucfirst($c->status)); ?></span>
                    <div style="display:flex;gap:6px;margin-top:8px;">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $c)): ?>  <a href="<?php echo e(route('admin.elections.candidates.edit', [$election, $c])); ?>" class="btn btn-secondary btn-sm" style="padding:4px 10px;font-size:12px;">Edit</a> <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $c)): ?> 
                        <form action="<?php echo e(route('admin.elections.candidates.destroy', [$election, $c])); ?>" method="POST">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm" style="padding:4px 10px;font-size:12px;" onclick="return confirm('Remove candidate?')">Remove</button>
                        </form> 
                    <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>
    </div>
</div>


<div id="pane-voters" class="tab-pane" style="display:none;">
    <div class="card">
        <div class="card-header">
            <div class="card-title">Voters</div>
            <div style="display:flex;gap:8px;">
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view.voters')): ?>  <a href="<?php echo e(route('admin.elections.voters.index', $election)); ?>" class="btn btn-primary btn-sm"> View Voters</a> <?php endif; ?>
            </div>
        </div>

        <div class="table-wrap">
            <table>
                <thead><tr><th>Email / Phone</th><th>Verified</th><th>Last Login</th><th>Actions</th></tr></thead>
                <tbody>
                    <tr><td colspan="4" style="text-align:center;color:var(--ink-3);padding:30px;">Loading voters…</td></tr>
                </tbody>
            </table>
        </div>
        <p style="font-size:13px;color:var(--ink-3);margin-top:12px;">
         <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view.voters')): ?> <a href="<?php echo e(route('admin.elections.voters.index', $election)); ?>" style="color:var(--accent);">View all voters →</a> <?php endif; ?>
        </p>
    </div>
</div>


<div id="pane-registration" class="tab-pane" style="display:none;">
    <div class="card">
        <div class="card-header">
            <div class="card-title">Voter Registration Form</div>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $election->setting)): ?>  <a href="<?php echo e(route('admin.elections.registration.show', $election)); ?>" class="btn btn-primary btn-sm">Form Builder</a> <?php endif; ?>
        </div>
        <?php if($election->registrationField): ?>
            <div class="alert alert-success" style="margin-bottom:0;">
                <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                Registration form configured with <?php echo e(count($election->registrationField->fields ?? [])); ?> field(s).
            </div>
        <?php else: ?>
            <div class="alert alert-info" style="margin-bottom:0;">
                <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 8v4m0 4h.01"/></svg>
             <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $election->setting)): ?>   No registration form set up yet. <a href="<?php echo e(route('admin.elections.registration.show', $election)); ?>" style="color:var(--accent);">Create one →</a> <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>


<div id="pane-results" class="tab-pane" style="display:none;">
    <div class="card">
        <div class="card-header">
            <div class="card-title">Live Results</div>
            <a href="<?php echo e(route('admin.elections.results', $election)); ?>" class="btn btn-primary btn-sm">Full Results</a>
        </div>
        <?php if($election->votes_count === 0): ?>
            <div class="empty-state">
                <svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><polyline points="22,12 18,12 15,21 9,3 6,12 2,12"/></svg>
                <div class="empty-title">No votes cast yet</div>
            </div>
        <?php else: ?>
            <p style="font-size:13px;color:var(--ink-3);"><?php echo e(number_format($election->votes_count)); ?> votes counted. <a href="<?php echo e(route('admin.elections.results', $election)); ?>" style="color:var(--accent);">View full breakdown →</a></p>
        <?php endif; ?>
    </div>
</div>

<script>
function showTab(name) {
    document.querySelectorAll('.tab-pane').forEach(p => p.style.display = 'none');
    document.querySelectorAll('.tab-btn').forEach(b => {
        b.style.borderBottomColor = 'transparent';
        b.style.color = 'var(--ink-3)';
    });
    document.getElementById('pane-' + name).style.display = 'block';
    const btn = document.getElementById('tab-' + name);
    btn.style.borderBottomColor = 'var(--accent)';
    btn.style.color = 'var(--accent)';
}
showTab('positions');
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\electionmanagement\resources\views/admin/elections/show.blade.php ENDPATH**/ ?>