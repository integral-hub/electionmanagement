<?php $isSelf = $isSelf ?? false; ?>
<?php $__env->startSection('page-title', $isSelf ? 'Update Profile' : (isset($user) ? 'Edit Staff Member' : 'Invite Staff')); ?>

<?php $__env->startSection('topbar-actions'); ?>
    <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-secondary btn-sm">← Back</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div style="max-width:520px;">
    <div class="card">
        <div style="margin-bottom:24px;">
            <h2 style="font-size:18px;font-weight:700;"><?php echo e($isSelf ? 'Update Profile' : (isset($user) ? 'Edit Staff Member' : 'Invite Staff Member')); ?></h2>
            <p style="font-size:14px;color:var(--ink-3);margin-top:4px;">
                <?php echo e($isSelf ? 'Update your profile' : (isset($user) ? 'Update staff details and role.' : 'They\'ll receive an email with login credentials.')); ?>

            </p>
        </div>

        <form action="<?php echo e(isset($user) ? route('admin.users.update', $user) : route('admin.users.store')); ?>" method="POST" class="form-section">
            <?php echo csrf_field(); ?>
            <?php if(isset($user)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

            <div class="form-group">
                <label class="form-label" for="name">Full Name <span style="color:var(--danger)">*</span></label>
                <input type="text" id="name" name="name" class="form-input <?php echo e($errors->has('name') ? 'error' : ''); ?>" value="<?php echo e(old('name', $user?->name ?? '')); ?>" placeholder="Jane Doe" required>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="form-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label class="form-label" for="email">Email Address <span style="color:var(--danger)">*</span></label>
                <input type="email" id="email" name="email" class="form-input <?php echo e($errors->has('email') ? 'error' : ''); ?>" value="<?php echo e(old('email', $user?->email ?? '')); ?>" placeholder="jane@example.com"
                   <?php echo e($isSelf ? 'readonly style=background:#f1f5f9;cursor:not-allowed;' : ''); ?> required>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="form-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

           <?php if(!$isSelf): ?> 
            <div class="form-group">
                <label class="form-label" for="role">Role <span style="color:var(--danger)">*</span></label>
                <select id="role" name="role" class="form-select <?php echo e($errors->has('role') ? 'error' : ''); ?>" required>
                    <option value="">Select a role…</option>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($role->name); ?>" <?php echo e(old('role', $user?->roles?->first()?->name ?? '') === $role->name ? 'selected' : ''); ?>><?php echo e($role->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="form-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <?php endif; ?>

            <?php if(!isset($user)): ?>
            <div class="alert alert-info" style="margin:0;">
                <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="16" height="16"><circle cx="12" cy="12" r="10"/><path d="M12 8v4m0 4h.01"/></svg>
                A secure temporary password will be generated and emailed to the new user.
            </div>
            <?php endif; ?>

            <div style="display:flex;gap:10px;padding-top:8px;">
                <button type="submit" class="btn btn-primary">
                    <?php echo e($isSelf ? 'Update Profile' : (isset($user) ? 'Update Member' : 'Send Invitation')); ?>

                </button>
                <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\electionmanagement\resources\views/admin/users/create.blade.php ENDPATH**/ ?>