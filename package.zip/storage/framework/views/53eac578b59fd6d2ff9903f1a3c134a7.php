<?php $__env->startSection('page-title', 'Results — ' . $election->name); ?>

<?php $__env->startPush('styles'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/admin-results.css'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('topbar-actions'); ?>
    <a href="<?php echo e(route('admin.elections.show', $election)); ?>" class="btn btn-secondary btn-sm">← Election</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php
    $electionStatus = $election->status;

    $electionStatusColor = match($electionStatus) {
        'completed' => '#16a34a',
        'cancelled'    => '#dc2626',
        'running'   => '#f59e0b',
        'scheduled'   => '#4f46e5',
        'paused'   => '#9ca3af',
        default     => '#4f46e5',
    };
?>


<div class="card results-header">
    <div>
        <div class="card-title"><?php echo e($election->name); ?></div>
        <div class="results-header-sub">Election results overview</div>
    </div>

    <span class="status-pill" style="color: <?php echo e($electionStatusColor); ?>;">
        <?php echo e($electionStatus); ?>

    </span>
</div>


<div class="card turnout-grid">
    <div class="turnout-donut-wrap">
        <div class="turnout-donut" style="--pct: <?php echo e($turnoutPercent); ?>">
            <div class="turnout-donut-inner">
                <div class="turnout-donut-value"><?php echo e($turnoutPercent); ?>%</div>
                <div class="turnout-donut-label">Turnout</div>
            </div>
        </div>
    </div>

    <div class="turnout-stats">
        <div>
            <div class="turnout-stat-label">Eligible Voters</div>
            <div class="turnout-stat-value"><?php echo e(number_format($eligibleVoters)); ?></div>
        </div>
        <div>
            <div class="turnout-stat-label">Voters Who Voted</div>
            <div class="turnout-stat-value"><?php echo e(number_format($votedCount)); ?></div>
        </div>
        <div>
            <div class="turnout-stat-label">Total Ballots Cast</div>
            <div class="turnout-stat-value"><?php echo e(number_format($totalVotes)); ?></div>
        </div>
    </div>
</div>


<?php if($timeline->isNotEmpty()): ?>
    <?php
        $maxCumulative = max(1, $timeline->max('cumulative'));
        $width = 700;
        $height = 160;
        $count = $timeline->count();
        $stepX = $count > 1 ? $width / ($count - 1) : 0;

        $points = $timeline->values()->map(function ($point, $i) use ($stepX, $height, $maxCumulative) {
            $x = round($i * $stepX, 1);
            $y = round($height - (($point['cumulative'] / $maxCumulative) * ($height - 10)) - 5, 1);
            return ['x' => $x, 'y' => $y, 'date' => $point['date'], 'cumulative' => $point['cumulative'], 'votes' => $point['votes']];
        });

        $linePath = $points->map(fn ($p) => "{$p['x']},{$p['y']}")->implode(' ');
        $areaPath = "0,{$height} " . $linePath . " {$width},{$height}";
    ?>

    <div class="card">
        <div class="card-header">
            <div>
                <div class="card-title">Voting Timeline</div>
                <div class="results-header-sub">Cumulative ballots cast over time</div>
            </div>
        </div>

        <div class="timeline-chart-wrap">
            <svg class="timeline-svg" viewBox="0 0 <?php echo e($width); ?> <?php echo e($height); ?>" preserveAspectRatio="none">
                <line class="timeline-axis" x1="0" y1="<?php echo e($height - 1); ?>" x2="<?php echo e($width); ?>" y2="<?php echo e($height - 1); ?>" />
                <polygon class="timeline-area" points="<?php echo e($areaPath); ?>" />
                <polyline class="timeline-line" points="<?php echo e($linePath); ?>" />
                <?php $__currentLoopData = $points; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <circle class="timeline-point" cx="<?php echo e($p['x']); ?>" cy="<?php echo e($p['y']); ?>" r="3">
                        <title><?php echo e($p['date']); ?>: <?php echo e(number_format($p['cumulative'])); ?> total (<?php echo e(number_format($p['votes'])); ?> that day)</title>
                    </circle>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </svg>
            <div class="timeline-labels">
                <span><?php echo e($points->first()['date']); ?></span>
                <?php if($points->count() > 1): ?>
                    <span><?php echo e($points->last()['date']); ?></span>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php endif; ?>


<?php if($results->isEmpty()): ?>
    <div class="card">
        <div class="empty-state results-empty">
            <svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
                <polyline points="22,12 18,12 15,21 9,3 6,12 2,12"/>
            </svg>
            <div class="empty-title">No results yet</div>
            <p>Results will appear once voting begins.</p>
        </div>
    </div>
<?php else: ?>
    <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card result-card">
        <div class="card-header">
            <div>
                <div class="card-title"><?php echo e($result['position']->title); ?></div>
                <div class="result-card-sub"><?php echo e(number_format($result['total_votes'])); ?> votes cast</div>
            </div>
            <span class="result-candidate-count"><?php echo e(count($result['candidates'])); ?> candidates</span>
        </div>

        <div class="candidate-list">
            <?php $__currentLoopData = $result['candidates']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $candidate = $item['candidate'];
                    $votes = $item['votes'];
                    $pct = $item['percent'];

                    $candidateStatus = $candidate->status ?? 'inactive';

                    $candidateStatusColor = match($candidateStatus) {
                        'active'    => '#16a34a',
                        'withdrawn'  => '#6b7280',
                        default     => '#6b7280',
                    };
                ?>

                <div class="candidate-row">
                    <div class="candidate-rank <?php echo e($i === 0 && $votes > 0 ? 'is-leading' : ''); ?>"><?php echo e($i + 1); ?></div>

                    <div class="candidate-photo">
                        <?php if(data_get($candidate, 'photo.url')): ?>
                            <img src="<?php echo e(data_get($candidate, 'photo.url')); ?>" alt="<?php echo e($candidate->name); ?>">
                        <?php endif; ?>
                    </div>

                    <div class="candidate-details">
                        <div class="candidate-details-top">
                            <span class="candidate-name"><?php echo e($candidate->name); ?></span>
                            <span class="candidate-tally">
                                <?php echo e($pct); ?>%
                                <span class="candidate-tally-count">(<?php echo e(number_format($votes)); ?>)</span>
                            </span>
                        </div>

                        <div class="candidate-bar-track">
                            <div class="candidate-bar-fill" style="width: <?php echo e($pct); ?>%;"></div>
                        </div>

                        <div class="candidate-status-wrap">
                            <span class="candidate-status" style="color: <?php echo e($candidateStatusColor); ?>;">
                                <?php echo e($candidateStatus); ?>

                            </span>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\electionmanagement\resources\views/admin/results/show.blade.php ENDPATH**/ ?>