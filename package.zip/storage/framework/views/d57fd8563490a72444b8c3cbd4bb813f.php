<?php $__env->startSection('page-title', isset($role) ? 'Edit Role' : 'Create Role'); ?>

<?php $__env->startSection('topbar-actions'); ?>
    <a href="<?php echo e(route('admin.roles.index')); ?>" class="btn btn-secondary btn-sm">← Roles</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div style="max-width:700px;">
    <div class="card">
        <div style="margin-bottom:24px;">
            <h2 style="font-size:18px;font-weight:700;"><?php echo e(isset($role) ? 'Edit Role: '.$role->name : 'New Role'); ?></h2>
        </div>

        <form action="<?php echo e(isset($role) ? route('admin.roles.update', $role) : route('admin.roles.store')); ?>" method="POST" class="form-section">
            <?php echo csrf_field(); ?>
            <?php if(isset($role)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

            <div class="form-group">
                <label class="form-label">Role Name <span style="color:var(--danger)">*</span></label>
                <input type="text" name="name" class="form-input <?php echo e($errors->has('name')?'error':''); ?>" value="<?php echo e(old('name',$role->name??'')); ?>" placeholder="e.g. Election Manager" required>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="form-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div>
                <label class="form-label" style="margin-bottom:12px;display:block;">Permissions</label>
                <div style="display:flex;justify-content:flex-end;gap:8px;margin-bottom:10px;">
                    <button type="button" onclick="toggleAll(true)" class="btn btn-secondary btn-sm">Select All</button>
                    <button type="button" onclick="toggleAll(false)" class="btn btn-secondary btn-sm">Clear All</button>
                </div>

                <?php
                    $grouped = collect($permissions)->groupBy(fn($p) => explode('.', $p->value)[0] ?? 'other');
                    $activePerms = isset($role) ? $role->permissions->pluck('name')->toArray() : [];
                ?>

                <?php $__currentLoopData = $grouped; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group => $perms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div style="margin-bottom:16px;border:1px solid var(--border);border-radius:10px;overflow:hidden;">
                    <div style="background:var(--surface);padding:10px 14px;font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:var(--ink-3);"><?php echo e(ucfirst($group)); ?></div>
                    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:0;">
                        <?php $__currentLoopData = $perms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label style="display:flex;align-items:center;gap:8px;padding:10px 14px;cursor:pointer;font-size:13px;border-top:1px solid var(--border);">
                            <input type="checkbox" name="permissions[]" value="<?php echo e($perm->value); ?>" class="perm-check"
                                <?php echo e(in_array($perm->value, old('permissions', $activePerms)) ? 'checked' : ''); ?>

                                style="accent-color:var(--accent);width:15px;height:15px;">
                            <?php echo e(str_replace(['.','_'], [' ', ' '], $perm->value)); ?>

                        </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div style="display:flex;gap:10px;padding-top:8px;border-top:1px solid var(--border);">
                <button type="submit" class="btn btn-primary"><?php echo e(isset($role) ? 'Update Role' : 'Create Role'); ?></button>
                <a href="<?php echo e(route('admin.roles.index')); ?>" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>

<script>
function toggleAll(check) {
    document.querySelectorAll('.perm-check').forEach(c => c.checked = check);
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\electionmanagement\resources\views/admin/roles/create.blade.php ENDPATH**/ ?>