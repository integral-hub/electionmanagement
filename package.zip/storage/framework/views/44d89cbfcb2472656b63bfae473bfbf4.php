<?php $__env->startSection('page-title', isset($position) ? 'Edit Position' : 'Add Position'); ?>
<?php $__env->startSection('topbar-actions'); ?>
    <a href="<?php echo e(route('admin.elections.show', $election)); ?>" class="btn btn-secondary btn-sm">← Election</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div style="max-width:520px;">
    <div class="card">
        <div style="margin-bottom:24px;">
            <h2 style="font-size:18px;font-weight:700;"><?php echo e(isset($position) ? 'Edit Position' : 'Add Position'); ?></h2>
            <p style="font-size:14px;color:var(--ink-3);">Election: <strong><?php echo e($election->name); ?></strong></p>
        </div>

        <form action="<?php echo e(isset($position) ? route('admin.elections.positions.update',[$election,$position]) : route('admin.elections.positions.store',$election)); ?>" method="POST" class="form-section">
            <?php echo csrf_field(); ?>
            <?php if(isset($position)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

            <div class="form-group">
                <label class="form-label" for="title">Position Title *</label>
                <input type="text" id="title" name="title" class="form-input <?php echo e($errors->has('title')?'error':''); ?>" value="<?php echo e(old('title',$position->title??'')); ?>" placeholder="e.g. President, Secretary General" required>
                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="form-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label class="form-label" for="description">Description <span class="form-hint">(optional)</span></label>
                <textarea id="description" name="description" class="form-textarea" placeholder="Brief description of this role…"><?php echo e(old('description',$position->description??'')); ?></textarea>
            </div>

            <div style="display:flex;gap:10px;padding-top:8px;">
                <button type="submit" class="btn btn-primary"><?php echo e(isset($position) ? 'Update Position' : 'Add Position'); ?></button>
                <a href="<?php echo e(route('admin.elections.show', $election)); ?>" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\electionmanagement\resources\views/admin/positions/create.blade.php ENDPATH**/ ?>