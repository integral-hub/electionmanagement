<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startSection('topbar-actions'); ?>
    <a href="<?php echo e(route('admin.elections.index')); ?>" class="btn btn-primary btn-sm">
        <span class="badge-dot"></span>
        Elections
    </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon" style="background:#eef2ff;">
            <svg width="20" height="20" fill="none" stroke="#4f46e5" stroke-width="2" viewBox="0 0 24 24"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2"/></svg>
        </div>
        <div class="stat-label">Total Elections</div>
        <div class="stat-value"><?php echo e($stats['elections']); ?></div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background:#fef9c3;">
            <svg width="20" height="20" fill="none" stroke="#d97706" stroke-width="2" viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>
        </div>
        <div class="stat-label">Total Voters</div>
        <div class="stat-value"><?php echo e(number_format($stats['total_voters'])); ?></div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background:#cdc3fe;">
            <svg width="20" height="20" fill="none" stroke="#d97706" stroke-width="2" viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>
        </div>
        <div class="stat-label">Staff</div>
        <div class="stat-value"><?php echo e(number_format($stats['staff'])); ?></div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background:#dcfce7;">
            <svg width="20" height="20" fill="none" stroke="#059669" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12,6 12,12 16,14"/></svg>
        </div>
        <div class="stat-label">Running Elections</div>
        <div class="stat-value"><?php echo e($stats['active']); ?></div>
    </div>
</div>

<div style="display:grid;grid-template-columns:1fr 340px;gap:24px;">
    <!-- Recent Elections -->
    <div class="card">
        <div class="card-header">
            <div class="card-title">Recent Elections</div>
            <a href="<?php echo e(route('admin.elections.index')); ?>" class="btn btn-secondary btn-sm">View all</a>
        </div>
        <?php if($recentElections->isEmpty()): ?>
            <div class="empty-state">
                <svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2"/></svg>
                <div class="empty-title">No elections yet</div>
                <p style="font-size:13px;">Create your first election to get started.</p>
            </div>
        <?php else: ?>
            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Status</th>
                            <th>Voters</th>
                            <th>Created</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $recentElections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $election): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><a href="<?php echo e(route('admin.elections.show', $election)); ?>" style="font-weight:500;color:var(--ink);text-decoration:none;"><?php echo e($election->name); ?></a></td>
                            <td><span class="badge badge-<?php echo e($election->status); ?>"><span class="badge-dot"></span><?php echo e(ucfirst($election->status)); ?></span></td>
                            <td><?php echo e($election->voters->count() ?? '—'); ?></td>
                            <td style="color:var(--ink-3);font-size:13px;"><?php echo e($election->created_at->format('M j, Y')); ?></td>
                            <td><a href="<?php echo e(route('admin.elections.show', $election)); ?>" class="btn btn-secondary btn-sm">Manage</a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>

    <!-- Recent Audit Logs -->
    <div class="card">
        <div class="card-header">
            <div class="card-title">Recent Activity</div>
            <a href="<?php echo e(route('admin.audit-logs')); ?>" class="btn btn-secondary btn-sm">All</a>
        </div>
        <div style="display:flex;flex-direction:column;gap:12px;">
            <?php $__empty_1 = true; $__currentLoopData = $recentLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div style="display:flex;gap:10px;align-items:flex-start;">
                <div style="width:8px;height:8px;border-radius:50%;background:var(--accent);margin-top:5px;flex-shrink:0;"></div>
                <div>
                    <div style="font-size:13px;font-weight:500;"><?php echo e($log->description ?? 'Action logged'); ?></div>
                    <div style="font-size:11px;color:var(--ink-3);"><?php echo e($log->created_at?->diffForHumans()); ?></div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div style="font-size:13px;color:var(--ink-3);text-align:center;padding:20px 0;">No activity yet.</div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\electionmanagement\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>