<?php $__env->startSection('page-title', 'Voter Status'); ?>

<?php $__env->startSection('page-subtitle'); ?>
    <?php
        $pivotStatus = $pivot?->status ?? 'pending';

        $statusMap = [
            'validated' => ['b-running', 'Validated'],
            'banned'    => ['b-rejected', 'Banned'],
            'pending'   => ['b-scheduled', 'Pending'],
        ];

        [$badgeClass, $statusLabel] = $statusMap[$pivotStatus] ?? ['b-draft', ucfirst($pivotStatus)];
    ?>

    <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
        <span class="badge <?php echo e($badgeClass); ?>">
            <span class="bd"></span><?php echo e($statusLabel); ?>

        </span>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('topbar-actions'); ?>
    <a href="<?php echo e(route('admin.elections.voters.index', $election)); ?>" class="btn btn-s btn-sm">← Voters</a>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $voter)): ?>
    <a href="<?php echo e(route('admin.elections.voters.edit', [$election, $voter])); ?>" class="btn btn-p btn-sm">
        <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="13" height="13"><path d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
        Edit
    </a>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div style="display:flex;align-items:center;gap:12px;margin-bottom:20px;flex-wrap:wrap;">

    <?php if($pivot?->validated_at): ?>
        <span style="font-size:12px;color:var(--ink3);">
            <?php echo e(ucfirst($pivot?->status)); ?> by
            <strong>
                <?php if($pivot->validated_by === auth()->id()): ?>
                    You
                <?php else: ?>
                    <?php echo e($pivot->validator?->name ?? 'Unknown User'); ?>

                    <?php if($pivot->validator?->getRoleNames()->isNotEmpty()): ?>
                        (<?php echo e(ucfirst($pivot->validator->getRoleNames()->first())); ?>)
                    <?php endif; ?>
                <?php endif; ?>
            </strong>
            on <?php echo e(\Carbon\Carbon::parse($pivot->validated_at)->format('M j, Y \a\t H:i')); ?>

        </span>
    <?php endif; ?>

    <?php if($pivotStatus !== 'validated'): ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('approve', $voter)): ?>
    <form action="<?php echo e(route('admin.elections.voters.approve', [$election, $voter])); ?>" method="POST" style="display:inline;">
        <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
        <button type="submit" class="btn btn-sg btn-sm">
            <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="13" height="13"><path d="M5 13l4 4L19 7"/></svg>
            Approve
        </button>
    </form>
    <?php endif; ?>
    <?php endif; ?>

    <?php if($pivotStatus !== 'banned'): ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reject', $voter)): ?>
    <form action="<?php echo e(route('admin.elections.voters.reject', [$election, $voter])); ?>" method="POST" style="display:inline;">
        <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
        <button type="submit" class="btn btn-d btn-sm"
                onclick="return confirm('Ban this voter from the election?')">
            <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="13" height="13"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            Ban
        </button>
    </form>
    <?php endif; ?>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $voter)): ?>
    <form action="<?php echo e(route('admin.elections.voters.destroy', [$election, $voter])); ?>" method="POST" style="display:inline;">
        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
        <button type="submit" class="btn btn-d btn-sm"
                onclick="return confirm('Remove this voter from the election?')">
            Remove
        </button>
    </form>
    <?php endif; ?>
</div>

<div style="display:grid;grid-template-columns:320px 1fr;gap:18px;align-items:start;">

    
    <div style="display:flex;flex-direction:column;gap:16px;">

        
        <div class="card">
            <div class="ch" style="margin-bottom:14px;"><div class="ct">Identity</div></div>

            <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;">
                <div style="width:50px;height:50px;border-radius:50%;background:var(--acl);display:grid;place-items:center;flex-shrink:0;font-size:19px;font-weight:700;color:var(--ac);">
                    <?php echo e(strtoupper(substr($voter->email ?? $voter->phone ?? 'V', 0, 1))); ?>

                </div>
                <div>
                    <div style="font-size:13.5px;font-weight:600;"><?php echo e($voter->email ?? $voter->phone ?? 'Unknown'); ?></div>
                </div>
            </div>

            
            <div style="padding:9px 0;border-bottom:1px solid var(--bdr);">
                <div style="font-size:10.5px;font-weight:600;text-transform:uppercase;letter-spacing:.05em;color:var(--ink3);margin-bottom:3px;">Email</div>
                <?php if($voter->email): ?>
                <div style="display:flex;align-items:center;gap:7px;">
                    <span style="font-size:13px;"><?php echo e($voter->email); ?></span>
                    <?php if($voter->is_verified_email): ?>
                        <span style="font-size:10.5px;color:var(--ok);background:#f0fdf4;padding:2px 7px;border-radius:20px;">✓ Verified</span>
                    <?php else: ?>
                        <span style="font-size:10.5px;color:var(--warn);background:#fffbeb;padding:2px 7px;border-radius:20px;">Unverified</span>
                    <?php endif; ?>
                </div>
                <?php else: ?>
                <span style="font-size:13px;color:var(--ink3);">—</span>
                <?php endif; ?>
            </div>

            
            <div style="padding:9px 0;border-bottom:1px solid var(--bdr);">
                <div style="font-size:10.5px;font-weight:600;text-transform:uppercase;letter-spacing:.05em;color:var(--ink3);margin-bottom:3px;">Phone</div>
                <div style="font-size:13px;"><?php echo e($voter->phone ?? '—'); ?></div>
            </div>

            
            <div style="padding:9px 0;border-bottom:1px solid var(--bdr);">
                <div style="font-size:10.5px;font-weight:600;text-transform:uppercase;letter-spacing:.05em;color:var(--ink3);margin-bottom:3px;">Batch Code</div>
                <?php if($voter->batch_code): ?>
                <code style="font-size:12px;background:var(--sur);padding:2px 7px;border-radius:4px;"><?php echo e($voter->batch_code); ?></code>
                <?php else: ?>
                <span style="font-size:13px;color:var(--ink3);">—</span>
                <?php endif; ?>
            </div>

            
            <div style="padding:9px 0;border-bottom:1px solid var(--bdr);">
                <div style="font-size:10.5px;font-weight:600;text-transform:uppercase;letter-spacing:.05em;color:var(--ink3);margin-bottom:3px;">Last Login</div>
                <div style="font-size:13px;"><?php echo e($voter->last_login_at?->format('M j, Y H:i') ?? '—'); ?></div>
            </div>

            
            <div style="padding:9px 0;">
                <div style="font-size:10.5px;font-weight:600;text-transform:uppercase;letter-spacing:.05em;color:var(--ink3);margin-bottom:3px;">Registered</div>
                <div style="font-size:13px;color:var(--ink2);"><?php echo e($voter->created_at->format('M j, Y \a\t H:i')); ?></div>
            </div>
        </div>

        
        <div class="card">
            <div class="ch" style="margin-bottom:14px;"><div class="ct">Election Details</div></div>
            <div style="display:flex;flex-direction:column;gap:10px;">
                <div>
                    <div style="font-size:10.5px;font-weight:600;text-transform:uppercase;letter-spacing:.05em;color:var(--ink3);margin-bottom:3px;">Election</div>
                    <div style="font-size:13.5px;font-weight:500;"><?php echo e($election->name); ?></div>
                </div>
                <div>
                    <div style="font-size:10.5px;font-weight:600;text-transform:uppercase;letter-spacing:.05em;color:var(--ink3);margin-bottom:3px;">Status</div>
                    <span class="badge <?php echo e($badgeClass); ?>" style="font-size:11.5px;"><span class="bd"></span><?php echo e($statusLabel); ?></span>
                </div>
                <?php if($voter->hasVote($election)): ?>
                <div>
                    <div style="font-size:10.5px;font-weight:600;text-transform:uppercase;letter-spacing:.05em;color:var(--ink3);margin-bottom:6px;">Voting Status</div>
                        <span class="badge b-completed" style="font-size:12px;padding:3px 10px;">
                            <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="11" height="11" style="margin-right:3px;"><polyline points="9,11 12,14 22,4"/></svg>
                            Voted
                        </span>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    
    <div style="display:flex;flex-direction:column;gap:16px;">

        
        <?php if(!empty($voter->voter_data)): ?>
        <div class="card">
            <div class="ch" style="margin-bottom:14px;">
                <div class="ct">Bio Data</div>
            </div>
            <div>
                <?php $__currentLoopData = $voter->voter_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fieldName => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $def   = $fieldDefs->get($fieldName);
                    $label = $def['label'] ?? ucwords(str_replace('_', ' ', $fieldName));
                    $type  = $def['field_type'] ?? 'text';
                    $isFile = $type === 'file';
                ?>
                <div style="display:grid;grid-template-columns:150px 1fr;gap:10px;padding:10px 0;<?php echo e(!$loop->last ? 'border-bottom:1px solid var(--bdr);' : ''); ?>align-items:start;">
                    <div style="font-size:11.5px;font-weight:600;color:var(--ink3);padding-top:2px;"><?php echo e($label); ?></div>
                    <div>
                        <?php if($isFile && $value): ?>
                            <?php
                                $ext = strtolower($value['format']);
                                $isImage = in_array($ext, ['jpg', 'jpeg', 'png']);
                                $isPdf = $ext === 'pdf';
                                $previewUrl = route('admin.elections.voters.file-preview', [$election, $voter, $fieldName]);
                            ?>
                            <div style="display:flex;flex-direction:column;gap:8px;">
                                <?php if($isImage): ?>
                                <a href="<?php echo e($previewUrl); ?>" target="_blank" rel="noopener"
                                   style="display:inline-block;border-radius:8px;overflow:hidden;border:1px solid var(--bdr);max-width:200px;">
                                    <img src="<?php echo e($previewUrl); ?>" alt="<?php echo e($label); ?>"
                                         style="width:100%;max-height:140px;object-fit:cover;display:block;">
                                </a>
                                <?php elseif($isPdf): ?>
                                <div style="border:1px solid var(--bdr);border-radius:8px;overflow:hidden;">
                                    <iframe src="<?php echo e($previewUrl); ?>" style="width:100%;height:200px;border:none;display:block;" title="<?php echo e($label); ?>"></iframe>
                                </div>
                                <?php else: ?>
                                <div style="display:flex;align-items:center;gap:8px;padding:9px 12px;border:1px solid var(--bdr);border-radius:8px;background:var(--sur);">
                                    <svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24" width="26" height="26" style="color:var(--ac);flex-shrink:0;"><path d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                                    <div>
                                        <div style="font-size:13px;font-weight:500;"><?php echo e($filename); ?></div>
                                        <div style="font-size:11px;color:var(--ink3);"><?php echo e(strtoupper($ext)); ?></div>
                                    </div>
                                </div>
                                <?php endif; ?>
                                <div style="display:flex;gap:7px;">
                                    <a href="<?php echo e($previewUrl); ?>" target="_blank" rel="noopener" class="btn btn-s btn-sm" style="font-size:11.5px;">
                                        <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="12" height="12"><path d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
                                        Open
                                    </a>
                                </div>
                            </div>

                        <?php elseif(is_array($value)): ?>
                            <div style="font-size:13px;"><?php echo e(implode(', ', $value)); ?></div>

                        <?php elseif(in_array($value, [true, false, '1', '0', 1, 0], true)): ?>
                            <span class="badge <?php echo e($value ? 'b-running' : 'b-draft'); ?>" style="font-size:11px;">
                                <?php echo e($value ? 'Yes' : 'No'); ?>

                            </span>

                        <?php else: ?>
                            <div style="font-size:13.5px;word-break:break-word;"><?php echo e($value ?: '—'); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php endif; ?>

        
        <?php if($voter->uniqueData->isNotEmpty()): ?>
        <div class="card">
            <div class="ch" style="margin-bottom:14px;">
                <div class="ct">Additional Information</div>
            </div>
            <div>
                <?php $__currentLoopData = $voter->uniqueData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $def   = $fieldDefs->get($ud->field_name);
                    $label = $def['label'] ?? ucwords(str_replace('_', ' ', $ud->field_name));
                ?>
                <div style="display:grid;grid-template-columns:150px 1fr;gap:10px;padding:9px 0;<?php echo e(!$loop->last ? 'border-bottom:1px solid var(--bdr);' : ''); ?>align-items:center;">
                    <div>
                        <div style="font-size:11.5px;font-weight:600;color:var(--ink3);"><?php echo e($label); ?> :</div>
                    </div>
                    <div style="display:flex;align-items:center;gap:8px;">
                        <span style="font-size:13.5px;font-weight:500;word-break:break-all;"><?php echo e($ud->value); ?></span>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php endif; ?>

        
        <?php if(empty($voter->voter_data) && $voter->uniqueData->isEmpty()): ?>
        <div class="card">
            <div class="es" style="padding:28px;">
                <svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                <div class="et">Bio data not supplied or required</div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<style>
@media (max-width:768px) {
    [style*="grid-template-columns:320px"] { grid-template-columns:1fr !important; }
}
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\electionmanagement\resources\views/admin/voters/show.blade.php ENDPATH**/ ?>