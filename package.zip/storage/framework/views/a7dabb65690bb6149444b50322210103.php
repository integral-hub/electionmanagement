<?php $__env->startSection('title', 'Cast Your Vote'); ?>

<?php $__env->startSection('content'); ?>


<div style="margin-bottom:24px;">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
        <span style="font-size:13px;font-weight:600;color:var(--ink-2);">Your Ballot</span>
        <span style="font-size:13px;color:var(--ink-3);" id="progressLabel">0 of <?php echo e($election->positions->count()); ?> positions</span>
    </div>
    <div style="height:6px;background:var(--border);border-radius:10px;overflow:hidden;">
        <div id="progressBar" style="height:100%;background:var(--primary);border-radius:10px;transition:width .3s ease;width:0%;"></div>
    </div>
</div>

<form action="<?php echo e(route('voter.cast', $election)); ?>" method="POST" id="ballotForm">
    <?php echo csrf_field(); ?>

    <?php if($errors->any()): ?>
        <div class="v-alert v-alert-error"><?php echo e($errors->first()); ?></div>
    <?php endif; ?>

    <?php $__empty_1 = true; $__currentLoopData = $election->positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posIndex => $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="v-card position-card" id="pos-<?php echo e($position->id); ?>" style="margin-bottom:20px;transition:box-shadow .2s;">
        
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
            <div>
                <div style="font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.07em;color:var(--primary);margin-bottom:3px;">Position <?php echo e($posIndex + 1); ?></div>
                <h2 style="font-size:18px;font-weight:700;"><?php echo e($position->title); ?></h2>
                <?php if($position->description): ?>
                    <p style="font-size:13px;color:var(--ink-3);margin-top:2px;"><?php echo e($position->description); ?></p>
                <?php endif; ?>
            </div>
            <div id="check-<?php echo e($position->id); ?>" style="width:32px;height:32px;border-radius:50%;background:var(--border);display:grid;place-items:center;flex-shrink:0;transition:background .2s;">
                <svg fill="none" stroke="#fff" stroke-width="2.5" viewBox="0 0 24 24" width="16" height="16"><path d="M5 13l4 4L19 7"/></svg>
            </div>
        </div>

        
        <?php if($position->candidates->isEmpty()): ?>
            <p style="font-size:13px;color:var(--ink-3);text-align:center;padding:16px 0;">No candidates for this position.</p>
        <?php else: ?>
        <div style="display:flex;flex-direction:column;gap:10px;">
            <?php $__currentLoopData = $position->candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <label class="candidate-card" for="vote_<?php echo e($position->id); ?>_<?php echo e($candidate->id); ?>" style="display:flex;align-items:center;gap:14px;padding:14px 16px;border:2px solid var(--border);border-radius:12px;cursor:pointer;transition:all .15s;user-select:none;">
                <input
                    type="radio"
                    id="vote_<?php echo e($position->id); ?>_<?php echo e($candidate->id); ?>"
                    name="votes[<?php echo e($posIndex); ?>][candidate_id]"
                    value="<?php echo e($candidate->id); ?>"
                    data-position="<?php echo e($position->id); ?>"
                    onchange="onVoteSelect(this)"
                    style="display:none;"
                >
                <input type="hidden" name="votes[<?php echo e($posIndex); ?>][position_id]" value="<?php echo e($position->id); ?>">

                
                <div style="width:52px;height:52px;border-radius:50%;overflow:hidden;flex-shrink:0;background:var(--surface);border:2px solid var(--border);">
                <?php if(data_get($candidate, 'photo.url')): ?>
                <img src="<?php echo e(data_get($candidate, 'photo.url')); ?>"
                    alt="<?php echo e($candidate->name); ?>">
                <?php endif; ?>
                </div>

                
                <div style="flex:1;min-width:0;">
                    <div style="font-size:15px;font-weight:600;margin-bottom:2px;"><?php echo e($candidate->name); ?></div>
                    <?php if($candidate->bio): ?>
                        <div style="font-size:13px;color:var(--ink-3);"><?php echo e(Str::limit($candidate->bio, 80)); ?></div>
                    <?php endif; ?>
                    <?php if($candidate->manifesto): ?>
                        <div style="font-size:12px;color:var(--primary);margin-top:4px;font-style:italic;">"<?php echo e(Str::limit($candidate->manifesto, 70)); ?>"</div>
                    <?php endif; ?>
                </div>

                
                <div class="vote-indicator" style="width:22px;height:22px;border-radius:50%;border:2px solid var(--border);flex-shrink:0;display:grid;place-items:center;transition:all .15s;">
                    <div style="width:10px;height:10px;border-radius:50%;background:transparent;transition:background .15s;"></div>
                </div>
            </label>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="v-card" style="text-align:center;padding:40px;">
            <p style="color:var(--ink-3);">No positions have been set up for this election yet.</p>
        </div>
    <?php endif; ?>

    <?php if($election->positions->isNotEmpty()): ?>
    <div style="position:sticky;bottom:16px;z-index:10;">
        <button type="submit" class="v-btn v-btn-primary" id="submitBtn" style="box-shadow:0 4px 20px rgba(37,99,235,.35);" onclick="return confirmVote()">
            <svg fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24" width="18" height="18"><polyline points="9,11 12,14 22,4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/></svg>
            Submit My Votes
        </button>
    </div>
    <?php endif; ?>
</form>

<div style="text-align:center;margin-top:20px;font-size:12px;color:var(--ink-3);">
    <strong>Important:</strong> Once submitted, your votes cannot be changed.
</div>

<style>
.candidate-card:has(input:checked) {
    border-color: var(--primary);
    background: var(--primary-light);
}
.candidate-card:has(input:checked) .vote-indicator {
    border-color: var(--primary);
    background: var(--primary);
}
.candidate-card:has(input:checked) .vote-indicator div {
    background: #fff;
}
.candidate-card:hover {
    border-color: #93c5fd;
    background: #f8fbff;
}
</style>

<script>
const totalPositions = <?php echo e($election->positions->count()); ?>;
const voted = new Set();

function onVoteSelect(input) {
    voted.add(input.dataset.position);
    updateProgress();
    // Mark the position card as done
    const checkEl = document.getElementById('check-' + input.dataset.position);
    if (checkEl) checkEl.style.background = 'var(--success)';
}

function updateProgress() {
    const pct = totalPositions > 0 ? (voted.size / totalPositions) * 100 : 0;
    document.getElementById('progressBar').style.width = pct + '%';
    document.getElementById('progressLabel').textContent = voted.size + ' of ' + totalPositions + ' positions';
}

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.voter', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\electionmanagement\resources\views/voter/ballot.blade.php ENDPATH**/ ?>