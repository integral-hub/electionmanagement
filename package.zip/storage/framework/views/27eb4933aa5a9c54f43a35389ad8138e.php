<?php $__env->startSection('title', 'Voter Login'); ?>

<?php $__env->startSection('content'); ?>
<div class="v-card">
    <div style="text-align:center;margin-bottom:28px;">
        <div style="width:56px;height:56px;background:var(--primary-light);border-radius:16px;display:grid;place-items:center;margin:0 auto 16px;">
            <svg fill="none" stroke="var(--primary)" stroke-width="2" viewBox="0 0 24 24" width="28" height="28">
                <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/>
                <circle cx="12" cy="7" r="4"/>
            </svg>
        </div>

        <h1 style="font-size:22px;font-weight:700;margin-bottom:6px;">Voter Login</h1>
        <p style="font-size:14px;color:var(--ink-3);">
            Enter your credentials to access the ballot.
        </p>
    </div>

    <?php if($errors->any()): ?>
        <div class="v-alert v-alert-error">
            <?php echo e($errors->first()); ?>

        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('voter.login.submit', $election)); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <?php $__currentLoopData = $loginFields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php switch($field['key']):

                case ('email'): ?>
                    <div class="v-form-group">
                        <label class="v-label" for="email">
                            <?php echo e($field['label']); ?>

                            <span style="color:#dc2626;">*</span>
                        </label>

                        <input
                            type="email"
                            id="email"
                            name="email"
                            class="v-input"
                            placeholder="you@example.com"
                            value="<?php echo e(old('email')); ?>"
                            autocomplete="email"
                            required>
                    </div>
                    <?php break; ?>

                <?php case ('phone'): ?>
                    <div class="v-form-group">
                        <label class="v-label" for="phone">
                            <?php echo e($field['label']); ?>

                            <span style="color:#dc2626;">*</span>
                        </label>

                        <input
                            type="tel"
                            id="phone"
                            name="phone"
                            class="v-input"
                            placeholder="+234 7xxxxxxxxx"
                            value="<?php echo e(old('phone')); ?>"
                            required>
                    </div>
                    <?php break; ?>

                <?php case ('password'): ?>
                    <div class="v-form-group">
                        <label class="v-label" for="password">
                            <?php echo e($field['label']); ?>

                            <span style="color:#dc2626;">*</span>
                        </label>

                        <div style="position:relative;">
                            <input
                                type="password"
                                id="password"
                                name="password"
                                class="v-input"
                                placeholder="Password"
                                autocomplete="current-password"
                                style="padding-right:44px;"
                                required>

                            <button
                                type="button"
                                onclick="togglePwd(this)"
                                style="position:absolute;right:12px;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;color:var(--ink-3);">
                                👁
                            </button>
                        </div>
                                <!-- FORGOT PASSWORD -->
                        <div style="text-align:right;margin-top:6px;">
                            <a href="<?php echo e(route('voter.password.request', $election)); ?>"
                            style="font-size:12px;color:var(--primary);text-decoration:none;">
                                Forgot password?
                            </a>
                        </div>
                    </div>
                    <?php break; ?>

                <?php default: ?>
                    <div class="v-form-group">
                        <label class="v-label" for="<?php echo e($field['key']); ?>">
                            <?php echo e($field['label']); ?>

                            <span style="color:#dc2626;">*</span>
                        </label>

                        <input
                            type="text"
                            id="<?php echo e($field['key']); ?>"
                            name="<?php echo e($field['key']); ?>"
                            class="v-input"
                            value="<?php echo e(old($field['key'])); ?>"
                            placeholder="Enter your <?php echo e(strtolower($field['label'])); ?>"
                            required>
                    </div>

            <?php endswitch; ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <button type="submit" class="v-btn v-btn-primary" style="margin-top:8px;">
            Access Ballot
            <svg fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24" width="16" height="16">
                <path d="M5 12h14M12 5l7 7-7 7"/>
            </svg>
        </button>
    </form>

    <?php if($election->is_registration_open): ?>
        <div class="v-divider">or</div>

        <a href="<?php echo e(route('voter.register', $election)); ?>" class="v-btn v-btn-secondary">
            Register as a Voter
        </a>
    <?php endif; ?>
</div>

<div style="text-align:center;margin-top:20px;font-size:12px;color:var(--ink-3);">
    Your vote is private and secure. &nbsp;·&nbsp; Powered by <?php echo e(config('app.name')); ?>

</div>

<script>
function togglePwd(btn) {
    const input = btn.previousElementSibling;
    input.type = input.type === 'password' ? 'text' : 'password';
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.voter', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\electionmanagement\resources\views/voter/login.blade.php ENDPATH**/ ?>