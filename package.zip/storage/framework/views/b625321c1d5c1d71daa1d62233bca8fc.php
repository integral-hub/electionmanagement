<?php $__env->startSection('page-title', 'Election Settings'); ?>

<?php $__env->startSection('topbar-actions'); ?>
    <a href="<?php echo e(route('admin.elections.show', $election)); ?>" class="btn btn-secondary btn-sm">← Back to Election</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div style="max-width:680px;">
    <div class="card">
        <div style="margin-bottom:24px;">
            <h2 style="font-size:18px;font-weight:700;">Settings — <?php echo e($election->name); ?></h2>
            <p style="font-size:14px;color:var(--ink-3);margin-top:4px;">Configure registration, voting, and security options.</p>
        </div>

        <form action="<?php echo e(route('admin.elections.settings.update', $election)); ?>" method="POST" class="form-section">
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

            
            <div>
                <div style="font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:var(--ink-3);margin-bottom:12px;">Registration</div>
                <div class="form-group">
                    <label class="form-label">Registration Mode</label>
                    <div style="display:flex;gap:10px;flex-wrap:wrap;">
                        <?php $__currentLoopData = ['open'=>['Open – anyone can register','#059669'],'closed'=>['Closed – no new registrations','#dc2626']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mode => [$desc,$color]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label style="flex:1;min-width:160px;border:2px solid <?php echo e(old('registration_mode',$election->setting?->registration_mode) === $mode ? $color : 'var(--border)'); ?>;border-radius:10px;padding:14px;cursor:pointer;transition:border .15s;" class="radio-card">
                            <input type="radio" name="registration_mode" value="<?php echo e($mode); ?>" <?php echo e(old('registration_mode',$election->setting?->registration_mode) === $mode ? 'checked' : ''); ?> style="display:none;" onchange="updateRadioCards(this)">
                            <div style="font-weight:600;font-size:14px;margin-bottom:2px;"><?php echo e(ucfirst($mode)); ?></div>
                            <div style="font-size:12px;color:var(--ink-3);"><?php echo e($desc); ?></div>
                        </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php $__errorArgs = ['registration_mode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="form-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            
    <div style="font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:var(--ink-3);margin-bottom:12px;">
        Voters Validation Type
    </div>
            <div>
                <label style="display:flex;align-items:center;gap:10px;cursor:pointer;font-size:14px;">
                    <input type="checkbox" name="vote_before_validation" value="1" <?php echo e($election->setting?->vote_before_validation ? 'checked' : ''); ?> style="width:16px;height:16px;accent-color:var(--accent);">
                    Allow voters to cast votes before verification is complete
                </label>
                <p style="font-size:12px;color:var(--ink-3);margin-top:4px;margin-left:26px;">Voting will be held pending verification approval.</p>
            </div>


<div>
    <div style="font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:var(--ink-3);margin-bottom:12px;">
        Voter Login Field
    </div>
        <div style="margin-top:12px;padding:12px 14px;border:1px solid var(--border);border-radius:8px;background:var(--surface);font-size:13px;color:var(--ink-3);line-height:1.4;">
            <strong style="color:var(--danger);">IMPORTANT:</strong>
            You can customize voters login or use default <strong>Email & Password</strong>
        </div><br>

    <p style="font-size:12px;color:var(--ink-3);margin-bottom:10px;">
        You can select up to 3 fields voters can use to log in.
    </p>

    <?php
        $loginOptions = [
            'email' => 'email address',
            'phone' => 'phone number',
            'password' => 'password'
        ];

        $uniqueFields = collect($election->registrationField?->fields ?? [])
            ->filter(fn ($f) => $f['unique_field'] ?? false)
            ->pluck('label', 'field_name');

       $currentLoginFields = old('login_fields');

        $currentLoginFields = old('login_fields', $election->setting?->login_fields ?? []);
        $currentLoginFields = is_array($currentLoginFields) ? array_keys($currentLoginFields) : [];
    ?>

    
    <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:10px;">

        
        <?php $__currentLoopData = $loginOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <label style="display:flex;align-items:flex-start;gap:10px;cursor:pointer;font-size:14px;padding:10px;border:1px solid var(--border);border-radius:8px;">
            <input type="checkbox"
                   name="login_fields[]"
                   value="<?php echo e($value . ',' . $label); ?>"
                   <?php echo e(in_array($value, $currentLoginFields) ? 'checked' : ''); ?>

                   class="login-checkbox"
                   style="width:15px;height:15px;accent-color:var(--accent);margin-top:2px;">
            <div>
                <div style="font-weight:600;"><?php echo e(ucfirst($value)); ?></div>
                <div style="font-size:12px;color:var(--ink-3);"><?php echo e($label); ?></div>
            </div>
        </label>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        <?php $__currentLoopData = $uniqueFields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fieldName => $fieldLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <label style="display:flex;align-items:flex-start;gap:10px;cursor:pointer;font-size:14px;padding:10px;border:1px solid var(--border);border-radius:8px;">
            <input type="checkbox"
                   name="login_fields[]"
                   value="<?php echo e($fieldName . ',' . $fieldLabel); ?>"
                   <?php echo e(in_array($fieldName, $currentLoginFields) ? 'checked' : ''); ?>

                   class="login-checkbox"
                   style="width:15px;height:15px;accent-color:var(--accent);margin-top:2px;">
            <div>
                <div style="font-weight:600;"><?php echo e($fieldLabel); ?></div>
                <div style="font-size:12px;color:var(--ink-3);">
                    Custom unique field
                </div>
            </div>
        </label>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
    <p id="loginLimitMsg"
       style="font-size:12px;color:green;margin-top:8px;display:none;">
        <strong>You have reach maximum (3) login fields selection.</strong>
    </p>
    <?php $__errorArgs = ['login_fields'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="form-error"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

            
            <?php if(in_array($progress, [60, 80], true)): ?>
            <div>
                <div style="font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:var(--ink-3);margin-bottom:12px;">Voting Window</div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Start Date & Time</label>
                        <input type="datetime-local" name="voting_start" class="form-input" value="<?php echo e(old('voting_start', $election->setting?->voting_start?->format('Y-m-d\TH:i'))); ?>">
                        <?php $__errorArgs = ['voting_start'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="form-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label class="form-label">End Date & Time</label>
                        <input type="datetime-local" name="voting_end" class="form-input" value="<?php echo e(old('voting_end', $election->setting?->voting_end?->format('Y-m-d\TH:i'))); ?>">
                        <?php $__errorArgs = ['voting_end'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="form-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            

            
            <div>
                <div style="font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:var(--ink-3);margin-bottom:12px;">Two-Factor Auth</div>
                <div style="display:flex;gap:16px;align-items:center;flex-wrap:wrap;">
                    <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:14px;">
                        <input type="checkbox" name="voters_require_2fa" value="1" <?php echo e($election->setting?->voters_require_2fa ? 'checked' : ''); ?> id="twoFaToggle" onchange="document.getElementById('twoFaType').style.display=this.checked?'block':'none'" style="width:16px;height:16px;accent-color:var(--accent);">
                        Require 2FA for voters
                    </label>
                    <div id="twoFaType" style="<?php echo e($election->setting?->voters_require_2fa ? '' : 'display:none;'); ?>">
                        <select name="voters_2fa_type" class="form-select" style="width:auto;">
                            <?php $__currentLoopData = ['email'=>'Email']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val=>$lbl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($val); ?>" <?php echo e($election->setting?->voters_2fa_type === $val ? 'selected' : ''); ?>><?php echo e($lbl); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>

            <div style="display:flex;gap:10px;padding-top:8px;border-top:1px solid var(--border);">
                <button type="submit" class="btn btn-primary">Save Settings</button>
                <a href="<?php echo e(route('admin.elections.show', $election)); ?>" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>
<script>
function updateRadioCards(input) {
    document.querySelectorAll('.radio-card').forEach(card => {
        const radio = card.querySelector('input[type=radio]');
        const colors = { open:'#059669', closed:'#dc2626' };
        card.style.borderColor = radio.checked ? (colors[radio.value] || 'var(--accent)') : 'var(--border)';
    });
}
document.addEventListener('DOMContentLoaded', function () {
    const checkboxes = document.querySelectorAll('.login-checkbox');
    const max = 3;

    const msg = document.getElementById('loginLimitMsg');

    function updateUI() {
        const checked = document.querySelectorAll('.login-checkbox:checked');

        // show/hide warning
        msg.style.display = checked.length >= max ? 'block' : 'none';

        // disable unchecked when limit reached
        checkboxes.forEach(cb => {
            cb.disabled = (!cb.checked && checked.length >= max);
        });
    }

    checkboxes.forEach(cb => {
        cb.addEventListener('change', updateUI);
    });

    updateUI();
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\electionmanagement\resources\views/admin/elections/settings.blade.php ENDPATH**/ ?>