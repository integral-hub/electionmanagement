<?php $__env->startSection('page-title', 'Roles & Permissions'); ?>

<?php $__env->startSection('topbar-actions'); ?>
    <a href="<?php echo e(route('admin.roles.create')); ?>" class="btn btn-primary btn-sm">+ New Role</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <div class="card-title">Roles</div>
    </div>
    <div class="table-wrap">
        <table>
            <thead><tr><th>Role Name</th><th>Permissions</th><th>Users</th><th>Actions</th></tr></thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td style="font-weight:600;"><?php echo e($role->name); ?></td>
                    <td>
                        <span style="font-size:13px;color:var(--ink-3);"><?php echo e($role->permissions->count()); ?> permissions</span>
                    </td>
                    <td><?php echo e($role->users->count() ?? '—'); ?></td>
                    <td>
                        <div style="display:flex;gap:6px;">
                            <a href="<?php echo e(route('admin.roles.edit', $role)); ?>" class="btn btn-secondary btn-sm">Edit</a>
                            <form action="<?php echo e(route('admin.roles.destroy', $role)); ?>" method="POST">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger btn-sm" onclick="return confirm('Delete role?')">Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="4" style="text-align:center;color:var(--ink-3);padding:30px;">No roles defined yet.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div style="padding-top:16px;"><?php echo e($roles->links()); ?></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\electionmanagement\resources\views/admin/roles/index.blade.php ENDPATH**/ ?>