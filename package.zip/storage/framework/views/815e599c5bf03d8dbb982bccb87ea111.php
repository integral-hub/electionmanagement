<?php $__env->startSection('page-title', 'Elections'); ?>

<?php $__env->startSection('topbar-actions'); ?>
    <a href="<?php echo e(route('admin.elections.create')); ?>" class="btn btn-primary btn-sm">
        <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>
        New Election
    </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if($elections->isEmpty()): ?>
    <div class="card">
        <div class="empty-state">
            <svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01"/></svg>
            <div class="empty-title">No elections found</div>
            <p style="font-size:13px;margin-bottom:16px;">Create your first election to get started.</p>
            <a href="<?php echo e(route('admin.elections.create')); ?>" class="btn btn-primary btn-sm">Create Election</a>
        </div>
    </div>
<?php else: ?>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:20px;">
        <?php $__currentLoopData = $elections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $election): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card" style="padding:0;overflow:hidden;">
            <div style="padding:20px 20px 16px;">
                <div style="display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:10px;">
                    <span class="badge badge-<?php echo e($election->status); ?>">
                        <span class="badge-dot"></span><?php echo e(ucfirst($election->status)); ?>

                    </span>
                    <div class="dropdown">
                        <button data-dropdown style="background:none;border:none;cursor:pointer;padding:4px;border-radius:6px;color:var(--ink-3);">
                            <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="18" height="18"><circle cx="12" cy="5" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="12" cy="19" r="1"/></svg>
                        </button>
                        <div class="dropdown-menu">
                            <a href="<?php echo e(route('admin.elections.show', $election)); ?>" class="dropdown-item">
                                <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="15" height="15"><path d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
                                View
                            </a>
                            <a href="<?php echo e(route('admin.elections.edit', $election)); ?>" class="dropdown-item">
                                <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="15" height="15"><path d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                                Edit
                            </a>
                            <a href="<?php echo e(route('admin.elections.settings', $election)); ?>" class="dropdown-item">
                                <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="15" height="15"><path d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><circle cx="12" cy="12" r="3"/></svg>
                                Settings
                            </a>
                            <div class="dropdown-sep"></div>
                            <form action="<?php echo e(route('admin.elections.destroy', $election)); ?>" method="POST">
                                <?php echo csrf_field(); ?> 
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="dropdown-item danger" onclick="return confirm('Delete this election?')">
                                    <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="15" height="15"><polyline points="3,6 5,6 21,6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a1 1 0 011-1h4a1 1 0 011 1v2"/></svg>
                                    Delete
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                <h3 style="font-size:15px;font-weight:600;margin-bottom:6px;">
                    <a href="<?php echo e(route('admin.elections.show', $election)); ?>" style="text-decoration:none;color:var(--ink);"><?php echo e($election->name); ?></a>
                </h3>
                <?php if($election->description): ?>
                <p style="font-size:13px;color:var(--ink-3);line-height:1.5;"><?php echo e(Str::limit($election->description, 80)); ?></p>
                <?php endif; ?>
            </div>

            <div style="display:flex;gap:0;border-top:1px solid var(--border);">
                <?php $__currentLoopData = [['Positions', $election->positions_count], ['Candidates', $election->candidates_count], ['Voters', $election->voters_count]]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $count]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div style="flex:1;padding:10px;text-align:center;<?php echo e(!$loop->last ? 'border-right:1px solid var(--border);' : ''); ?>">
                    <div style="font-size:16px;font-weight:700;"><?php echo e($count ?? 0); ?></div>
                    <div style="font-size:11px;color:var(--ink-3);"><?php echo e($label); ?></div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div style="padding:12px 16px;border-top:1px solid var(--border);display:flex;gap:8px;">
                <a href="<?php echo e(route('admin.elections.show', $election)); ?>" class="btn btn-secondary btn-sm" style="flex:1;justify-content:center;">Manage</a>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div style="margin-top:24px;"><?php echo e($elections->links()); ?></div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\electionmanagement\resources\views/admin/elections/index.blade.php ENDPATH**/ ?>