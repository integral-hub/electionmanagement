<?php $__env->startSection('page-title', isset($candidate) ? 'Edit Candidate' : 'Add Candidate'); ?>
<?php $__env->startSection('topbar-actions'); ?>
    <a href="<?php echo e(route('admin.elections.show', $election)); ?>" class="btn btn-secondary btn-sm">← Election</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div style="max-width:560px;">
    <div class="card">
        <div style="margin-bottom:24px;">
            <h2 style="font-size:18px;font-weight:700;"><?php echo e(isset($candidate) ? 'Edit Candidate' : 'Add Candidate'); ?></h2>
            <p style="font-size:14px;color:var(--ink-3);">For election: <strong><?php echo e($election->name); ?></strong></p>
        </div>
        <form action="<?php echo e(isset($candidate) ? route('admin.elections.candidates.update', [$election,$candidate]) : route('admin.elections.candidates.store', $election)); ?>" method="POST" enctype="multipart/form-data" class="form-section">
            <?php echo csrf_field(); ?>
            <?php if(isset($candidate)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

            <div class="form-group">
                <label class="form-label">Position *</label>
                <select name="position_id" class="form-select <?php echo e($errors->has('position_id')?'error':''); ?>" required>
                    <option value="">Select position…</option>
                    <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($pos->id); ?>" <?php echo e(old('position_id', $candidate->position_id ?? '') == $pos->id ? 'selected' : ''); ?>><?php echo e($pos->title); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['position_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="form-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label class="form-label">Full Name *</label>
                <input type="text" name="name" class="form-input <?php echo e($errors->has('name')?'error':''); ?>" value="<?php echo e(old('name',$candidate->name??'')); ?>" required>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="form-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label class="form-label">Photo</label>
        <?php if(isset($candidate) && data_get($candidate, 'photo.url')): ?>
            <img src="<?php echo e(data_get($candidate, 'photo.url')); ?>"
                alt="<?php echo e($candidate->name); ?>">
        <?php endif; ?>
                <input type="file" name="photo" class="form-input" accept="image/*" style="padding:8px;">
                <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="form-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label class="form-label">Bio</label>
                <textarea name="bio" class="form-textarea" placeholder="Short biography…"><?php echo e(old('bio',$candidate->bio??'')); ?></textarea>
            </div>

            <div class="form-group">
                <label class="form-label">Manifesto / Tagline</label>
                <input type="text" name="manifesto" class="form-input" value="<?php echo e(old('manifesto',$candidate->manifesto??'')); ?>" placeholder="Their key campaign message">
            </div>

            <div class="form-group">
                <label class="form-label">Status</label>
                <select name="status" class="form-select">
                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($s); ?>" <?php echo e(old('status',$candidate->status ?? $statuses[0]) === $s ? 'selected' : ''); ?>><?php echo e(ucfirst($s)); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div style="display:flex;gap:10px;">
                <button type="submit" class="btn btn-primary"><?php echo e(isset($candidate) ? 'Update' : 'Add Candidate'); ?></button>
                <a href="<?php echo e(route('admin.elections.show', $election)); ?>" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\electionmanagement\resources\views/admin/candidates/create.blade.php ENDPATH**/ ?>