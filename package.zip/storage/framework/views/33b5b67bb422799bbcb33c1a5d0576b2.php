<?php $__env->startSection('page-title', 'Voters — ' . $election->name); ?>

<?php $__env->startSection('topbar-actions'); ?>
    <a href="<?php echo e(route('admin.elections.show', $election)); ?>" class="btn btn-secondary btn-sm">← Election</a>
  
 <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('assign.voters')): ?> <a href="<?php echo e(route('admin.elections.voters.assign.view', $election)); ?>" class="btn btn-primary btn-sm">+ Assign Voter</a> <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <div class="card-title">All Voters</div>
        <form action="" method="GET" style="display:flex;gap:8px;">
            <input type="search" name="q" class="form-input" placeholder="Search email / phone…" value="<?php echo e(request('q')); ?>" style="width:200px;">
            <select name="status" class="form-input" style="width:150px;">
                <option value="">Filter by status</option>
                <option value="validated" <?php echo e(request('status') == 'validated' ? 'selected' : ''); ?>>
                    Approved
                </option>
                <option value="pending" <?php echo e(request('status') == 'pending' ? 'selected' : ''); ?>>
                    Pending
                </option>
                <option value="banned" <?php echo e(request('status') == 'banned' ? 'selected' : ''); ?>>
                    Banned
                </option>
            </select>
            <button type="submit" class="btn btn-secondary btn-sm">Search</button>
            <?php if(request()->hasAny(['q','status'])): ?>
                <a href="<?php echo e(route('admin.elections.voters.index', $election)); ?>" class="btn btn-secondary btn-sm">Clear</a>
            <?php endif; ?>
        </form>
    </div>

    <?php if($voters->isEmpty()): ?>
        <div class="empty-state">
            <svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>
            <div class="empty-title">No voters assigned</div>
            <p style="font-size:13px;margin-bottom:14px;">Assign voters manually or import from CSV.</p>
            <a href="<?php echo e(route('admin.elections.voters.assign.view', $election)); ?>" class="btn btn-primary btn-sm">Assign Voters</a>
        </div>
    <?php else: ?>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Email Verified</th>
                    <th>Status</th>
                    <th>Last Login</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $voters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td style="font-weight:500;"><?php echo e($voter->email ?? '—'); ?></td>
                    <td style="color:var(--ink-3);"><?php echo e($voter->phone ?? '—'); ?></td>
                    <td>
                        <?php if($voter->is_verified_email): ?>
                            <span class="badge badge-running"><span class="badge-dot"></span> Yes</span>
                        <?php else: ?>
                            <span class="badge badge-cancelled"><span class="badge-dot"></span> No</span>
                        <?php endif; ?>
                    </td>
                    <?php
                    $status = $voter->pivot?->status;
                    ?>
                    <td>
                        <?php if($status === 'validated'): ?>
                            <span class="badge badge-running"><span class="badge-dot"></span>Approved</span>
                        <?php elseif($status === 'banned'): ?>
                            <span class="badge badge-cancelled"><span class="badge-dot"></span>Banned</span>
                        <?php else: ?>
                            <span class="badge badge-scheduled"><span class="badge-dot"></span>Pending</span>
                        <?php endif; ?>
                    </td>
                    <td style="color:var(--ink-3);font-size:13px;"><?php echo e($voter->last_login_at?->diffForHumans() ?? 'Never'); ?></td>
                    <td>
                        <div style="display:flex;gap:6px;">
                             <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', $voter)): ?>   <a href="<?php echo e(route('admin.elections.voters.show', [$election, $voter])); ?>" class="btn btn-secondary btn-sm">View</a> <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div style="padding:16px 0 0;"><?php echo e($voters->links()); ?></div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\electionmanagement\resources\views/admin/voters/index.blade.php ENDPATH**/ ?>