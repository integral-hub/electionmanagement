<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Vote'); ?> — <?php echo e($election?->name ?? config('app.name')); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/css/voter-layout.css', 'resources/js/app.js']); ?>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>

<header class="voter-header">
    <div class="voter-brand">
        <div class="voter-brand-mark">
            <svg viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
        </div>
        <div>
            <div class="election-name">
                <?php echo $__env->yieldContent('page-title', $election?->name); ?>
            </div>

            <div class="election-status">
                <?php if(isset($election->setting->voting_end)): ?>
                    Closes <?php echo e($election->setting->voting_end->format('M j, Y \a\t H:i')); ?>

                <?php else: ?>
                    Election Portal
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php if(auth()->guard('voter')->check()): ?>
    <div class="voter-actions">
        <?php echo $__env->yieldContent('topbar-actions'); ?>

        <a href="<?php echo e(route('voter.password.form', $election)); ?>" class="voter-change-password">
            Change Password
        </a>

        <form action="<?php echo e(route('voter.logout', $election)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button type="submit" class="voter-signout">
                Sign out
            </button>
        </form>
    </div>
    <?php endif; ?>
</header>

<div class="voter-container">
    <?php if(session('success')): ?>
        <div class="v-alert v-alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="v-alert v-alert-error"><?php echo e(session('error')); ?></div>
    <?php endif; ?>
    <?php if(session('info')): ?>
        <div class="v-alert v-alert-info"><?php echo e(session('info')); ?></div>
    <?php endif; ?>

    <?php echo $__env->yieldContent('content'); ?>
</div>

<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\laragon\www\electionmanagement\resources\views/layouts/voter.blade.php ENDPATH**/ ?>