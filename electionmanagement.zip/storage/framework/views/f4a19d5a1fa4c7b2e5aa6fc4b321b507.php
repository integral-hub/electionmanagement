<button
    <?php echo e($attributes->merge([
        'class' => 'w-full bg-black text-white py-2 rounded-lg hover:bg-gray-800'
    ])); ?>

>
    <?php echo e($slot); ?>

</button><?php /**PATH C:\laragon\www\electionmanagement\resources\views/components/ui/button.blade.php ENDPATH**/ ?>