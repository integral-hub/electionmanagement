<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo e(config('app.name')); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body class="bg-gray-100 flex items-center justify-center min-h-screen">

    <div class="w-full max-w-md">
        <?php echo e($slot); ?>

    </div>

</body>
</html><?php /**PATH C:\laragon\www\electionmanagement\resources\views/layouts/guest.blade.php ENDPATH**/ ?>