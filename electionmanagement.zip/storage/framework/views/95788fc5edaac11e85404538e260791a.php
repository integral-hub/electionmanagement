<div class="bg-white rounded-xl shadow p-6">
    <?php echo e($slot); ?>

</div><?php /**PATH C:\laragon\www\electionmanagement\resources\views/components/ui/card.blade.php ENDPATH**/ ?>