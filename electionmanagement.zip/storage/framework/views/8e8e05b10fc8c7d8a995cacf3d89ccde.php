<nav class="space-y-2">

    <a href="<?php echo e(route('dashboard')); ?>" class="block p-2 hover:bg-gray-100 rounded">
        Dashboard
    </a>

    <a href="<?php echo e(route('elections.index')); ?>" class="block p-2 hover:bg-gray-100 rounded">
        Elections
    </a>

    <a href="<?php echo e(route('roles.index')); ?>" class="block p-2 hover:bg-gray-100 rounded">
        Role
    </a>

    <a href="<?php echo e(route('users.index')); ?>" class="block p-2 hover:bg-gray-100 rounded">
        Staff
    </a>

</nav><?php /**PATH C:\laragon\www\electionmanagement\resources\views/components/nav/sidebar.blade.php ENDPATH**/ ?>