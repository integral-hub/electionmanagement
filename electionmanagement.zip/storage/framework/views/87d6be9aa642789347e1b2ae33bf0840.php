<!DOCTYPE html>
<html>
<head>
    <title><?php echo e(config('app.name')); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body class="bg-gray-100">

<div class="flex">

    <aside class="w-64 bg-white h-screen p-4 border-r">
        <?php echo $__env->make('components.nav.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </aside>

    <main class="flex-1 p-6">
        <?php echo e($slot); ?>

    </main>

</div>

</body>
</html><?php /**PATH C:\laragon\www\electionmanagement\resources\views/layouts/app.blade.php ENDPATH**/ ?>