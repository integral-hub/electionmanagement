<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\GuestLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

<div class="min-h-screen flex items-center justify-center px-4">

    <div class="w-full max-w-md">

        
        <div class="bg-white shadow-xl rounded-2xl overflow-hidden">

            
            <div class="bg-black text-white p-6 text-center">
                <h1 class="text-xl font-semibold">
                    Welcome Back
                </h1>
                <p class="text-sm text-gray-300 mt-1">
                    Sign in to continue
                </p>
            </div>

            
            <div class="p-6 space-y-5">

                
                <?php if($errors->any()): ?>
                    <div class="bg-red-50 text-red-600 p-3 rounded-lg text-sm">
                        <?php echo e($errors->first()); ?>

                    </div>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('login')); ?>" class="space-y-4">
                    <?php echo csrf_field(); ?>

                    
                    <div>
                        <label class="text-sm font-medium text-gray-600">
                            Email
                        </label>

                        <input
                            type="email"
                            name="email"
                            value="<?php echo e(old('email')); ?>"
                            placeholder="you@example.com"
                            class="mt-1 w-full rounded-lg border-gray-300 focus:border-black focus:ring-black"
                            required
                        >

                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-sm text-red-500 mt-1">
                                <?php echo e($message); ?>

                            </p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div>
                        <label class="text-sm font-medium text-gray-600">
                            Password
                        </label>

                        <input
                            type="password"
                            name="password"
                            placeholder="••••••••"
                            class="mt-1 w-full rounded-lg border-gray-300 focus:border-black focus:ring-black"
                            required
                        >

                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-sm text-red-500 mt-1">
                                <?php echo e($message); ?>

                            </p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="flex items-center justify-between text-sm">

                        <label class="flex items-center gap-2 text-gray-600">
                            <input type="checkbox" name="remember" class="rounded">
                            Remember me
                        </label>

                        <a href="#" class="text-black hover:underline">
                            Forgot password?
                        </a>

                    </div>

                    
                    <button
                        type="submit"
                        class="w-full bg-black text-white py-2.5 rounded-lg hover:bg-gray-900 transition"
                    >
                        Sign in
                    </button>

                </form>

            </div>

        </div>

        
        <p class="text-center text-xs text-gray-500 mt-4">
            © <?php echo e(date('Y')); ?> <?php echo e(config('app.name')); ?>. All rights reserved.
        </p>

    </div>

</div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\electionmanagement\resources\views/auth/login.blade.php ENDPATH**/ ?>